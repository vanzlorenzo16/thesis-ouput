=========================================================================================================
					Installation Procedure
=========================================================================================================
Please be guided with the following instructions and tips before using the developed system
-To install the developed system please perform the following instructions:

	1.Go to System Final >> Setup

- the system's database is not automatically included in the system and therefore should be imported within a specific dbms software(MySQL)
to install the dbms software and import the database please perform the following instructions:

	1. Install Mysql Software :
		To Locate the mysql installer go to:
		-Go to System Files >> Installers >> mysql-installer-community-5.7.20.0
		Watch the video in link:
		-https://www.youtube.com/watch?v=WuBcTJnIuzo
	2. Import the database file:
		To Locate the database File go to:
		-Go to System Files >> Database Backup
		Watch the video in link:
		-https://www.youtube.com/watch?v=Jvul-wr-_Bg

-To Setup a wireless LAN Connection
	1. Watch the video in link:
		https://www.youtube.com/watch?v=DCgRF4KOYIY