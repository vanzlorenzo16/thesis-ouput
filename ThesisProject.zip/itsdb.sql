-- MySQL dump 10.13  Distrib 5.7.20, for Win64 (x86_64)
--
-- Host: 192.168.43.13    Database: itsdb
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbladmscheckup`
--

DROP TABLE IF EXISTS `tbladmscheckup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladmscheckup` (
  `admscheckupid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `patcomplaints` varchar(300) DEFAULT NULL,
  `diagnosis` varchar(300) DEFAULT NULL,
  `remarks` varchar(300) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`admscheckupid`),
  KEY `patientid` (`patientid`),
  KEY `userid` (`userid`),
  CONSTRAINT `tbladmscheckup_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`),
  CONSTRAINT `tbladmscheckup_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbladmscheckup`
--

LOCK TABLES `tbladmscheckup` WRITE;
/*!40000 ALTER TABLE `tbladmscheckup` DISABLE KEYS */;
INSERT INTO `tbladmscheckup` VALUES (1001,1009,'2019-03-20','asd','asd','asd',1003),(1002,1001,'2019-03-20','Headache, Nausea','Migraine','Bedrest',1003),(1003,1001,'2019-03-25','asd','asd','asd',1003),(1004,1001,'2019-03-25','asd','asd','asd',1003),(1005,1001,'2019-03-25','asd','asd','asd',1003),(1006,1014,'2019-03-26','asd','asd','asd',1003),(1007,1001,'2019-03-26','asd','asd','asd',1003),(1008,1015,'2019-03-26','asd','asd','sd',1003),(1009,1014,'2019-03-26','asd','asd','sd',1003),(1010,1010,'2019-03-27','ads','asd','sd',1003),(1011,1010,'2019-03-27','asd','asd','asd',1003),(1012,1009,'2019-03-28','asd','asd','asd',1003),(1013,1010,'2019-04-02','asd','asd','asd',1003),(1014,1010,'2019-04-02','headache','migraine','take Prescribed medicine and enough bedrest',1003),(1015,1010,'2019-04-03','headache','migraine','take Prescribed medicine and enough bedrest',1003),(1016,1010,'2019-04-05','stomach ache','loose bowel movement','avoid oily food',1003),(1017,1010,'2019-04-05','asd','asdasd','asd',1003),(1018,1010,'2019-04-05','headache','migraine','bedrest',1003);
/*!40000 ALTER TABLE `tbladmscheckup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbladmsimmunization`
--

DROP TABLE IF EXISTS `tbladmsimmunization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladmsimmunization` (
  `admsimmunizationid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `vaccine_dosage` varchar(300) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `remarks` varchar(300) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `age_acquired` varchar(45) DEFAULT NULL,
  `weight` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`admsimmunizationid`),
  KEY `patientid` (`patientid`),
  KEY `userid` (`userid`),
  CONSTRAINT `tbladmsimmunization_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`),
  CONSTRAINT `tbladmsimmunization_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbladmsimmunization`
--

LOCK TABLES `tbladmsimmunization` WRITE;
/*!40000 ALTER TABLE `tbladmsimmunization` DISABLE KEYS */;
INSERT INTO `tbladmsimmunization` VALUES (1001,1002,'DPT - 3','2019-03-27','asdasd',1003,'1 yrs 7 mos 5 days','3.12 kg'),(1002,1005,'DPT - 1','2019-03-27','asd',1003,'Full Name','3.45 kg'),(1003,1004,'BCG - 1','2019-03-27','asd',1003,'1 yrs 2 mos 8 days','3.3 kg'),(1004,1002,'OPV - 1','2019-03-27','none',1003,'1 yrs 7 mos 5 days','3.23 kg'),(1005,1002,'DPT - 1','2019-03-28','none',1003,'1 yrs 7 mos 6 days','3.23 kg'),(1006,1003,'Measles - 1','2019-03-28','',1003,'Full Name','Full Name kg'),(1007,1002,'DPT - 1','2019-04-02','none',1003,'1 yrs 7 mos 11 days','15.34 kg');
/*!40000 ALTER TABLE `tbladmsimmunization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbladmsnbs`
--

DROP TABLE IF EXISTS `tbladmsnbs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladmsnbs` (
  `admsnbsid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `maternalsteroids` varchar(45) DEFAULT NULL,
  `steroidsdate` varchar(45) DEFAULT NULL,
  `birthingfacility` varchar(100) DEFAULT NULL,
  `collection` varchar(100) DEFAULT NULL,
  `followupclinic` varchar(200) DEFAULT NULL,
  `collectiondate` varchar(45) DEFAULT NULL,
  `birthorder` varchar(20) DEFAULT NULL,
  `specialconsiderations` varchar(100) DEFAULT NULL,
  `transfusion` varchar(50) DEFAULT NULL,
  `transfusiondate` varchar(45) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `birthweight` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`admsnbsid`),
  KEY `patientid` (`patientid`),
  KEY `userid` (`userid`),
  CONSTRAINT `tbladmsnbs_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`),
  CONSTRAINT `tbladmsnbs_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbladmsnbs`
--

LOCK TABLES `tbladmsnbs` WRITE;
/*!40000 ALTER TABLE `tbladmsnbs` DISABLE KEYS */;
INSERT INTO `tbladmsnbs` VALUES (1001,1003,'Yes','2019-01-22','Mahabang Parang RHU-II Birthing Facility','Mahabang Parang RHU-II Birthing Facility','Angono Pediatric Clinic','2019-03-20','Single','NICU, ANTIBIOTICS','Yes','2019-03-25',1003,'2019-03-20',NULL);
/*!40000 ALTER TABLE `tbladmsnbs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbladmspedia`
--

DROP TABLE IF EXISTS `tbladmspedia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladmspedia` (
  `admspediaid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `symptoms` varchar(300) DEFAULT NULL,
  `diagnosis` varchar(300) DEFAULT NULL,
  `remarks` varchar(300) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  PRIMARY KEY (`admspediaid`),
  KEY `patientid` (`patientid`),
  KEY `userid` (`userid`),
  CONSTRAINT `tbladmspedia_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`),
  CONSTRAINT `tbladmspedia_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbladmspedia`
--

LOCK TABLES `tbladmspedia` WRITE;
/*!40000 ALTER TABLE `tbladmspedia` DISABLE KEYS */;
INSERT INTO `tbladmspedia` VALUES (1001,1007,'2019-02-19','asd','asd','asd',1001),(1002,1002,'2019-03-20','upset stomach','loose bowel movement (lbm)','take prescribed medicine',1003),(1003,1011,'2019-03-20','headachec','biogeisc','need rest',1003),(1004,1002,'2019-03-26','asd','asd','none',1003),(1005,1002,'2019-03-26','asd','asd','asd',1003),(1006,1002,'2019-03-26','asd','asd','sd',1003),(1007,1002,'2019-03-27','asd','asd','asd',1003),(1008,1002,'2019-03-27','asd','asd','asd',1003),(1009,1002,'2019-03-28','asd','asd','asd',1003),(1010,1003,'2019-04-02','asd','asd','asd',1003);
/*!40000 ALTER TABLE `tbladmspedia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbladmsprenatal`
--

DROP TABLE IF EXISTS `tbladmsprenatal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbladmsprenatal` (
  `admsprenatalid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `servicesprovided` varchar(300) DEFAULT NULL,
  `dateofservice` date DEFAULT NULL,
  `remarks` varchar(300) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `instructions` varchar(300) DEFAULT NULL,
  `months_preganancy` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`admsprenatalid`),
  KEY `patientid` (`patientid`),
  KEY `userid` (`userid`),
  CONSTRAINT `tbladmsprenatal_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`),
  CONSTRAINT `tbladmsprenatal_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbladmsprenatal`
--

LOCK TABLES `tbladmsprenatal` WRITE;
/*!40000 ALTER TABLE `tbladmsprenatal` DISABLE KEYS */;
INSERT INTO `tbladmsprenatal` VALUES (1001,1001,'Ultrasound','2019-03-27','baby is in perfect condition',1003,'take enough bedrest','0 mos 22 days'),(1002,1009,'Ultrasound','2019-03-27','baby is in perfect condition',1003,'take prescribed supplements','0 mos 22 days'),(1003,1001,'asd','2019-03-27','baby is in perfect condition',1003,'no special instructions','0 mos 22 days'),(1004,1001,'asd','2019-03-28','asd',1003,'asd','0 mos 23 days'),(1005,1009,'Utrasound','2019-03-28','none',1003,'none','0 mos 17 days'),(1006,1001,'asd','2019-03-29','sd',1003,'asd','0 mos 24 days'),(1007,1009,'asd','2019-03-29','asd',1003,'asd','0 mos 18 days');
/*!40000 ALTER TABLE `tbladmsprenatal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblappointment`
--

DROP TABLE IF EXISTS `tblappointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblappointment` (
  `appointmentno` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `appointmentdate` date DEFAULT NULL,
  `appointmentday` varchar(45) DEFAULT NULL,
  `appointmentfor` varchar(45) DEFAULT NULL,
  `appointmenttime` varchar(45) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`appointmentno`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblappointment_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblappointment`
--

LOCK TABLES `tblappointment` WRITE;
/*!40000 ALTER TABLE `tblappointment` DISABLE KEYS */;
INSERT INTO `tblappointment` VALUES (1037,1004,'2019-03-29','Monday','Child Immunization','16:35:00 - 16:35:00','Expired'),(1038,1001,'2019-03-28','Thursday','Prenatal Checkup','16:35:00 - 16:35:00','Expired'),(1039,1001,'2019-04-01','Monday','Medical Adult Checkup','09:00:00 - 12:00:00','Expired'),(1040,1004,'2019-04-03','Wednesday','Child Immunization','08:00:00 - 12:00:00','Expired'),(1041,1001,'2019-04-02','Tuesday','Prenatal Checkup','08:00:00 - 05:00:00','Expired');
/*!40000 ALTER TABLE `tblappointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblaudit`
--

DROP TABLE IF EXISTS `tblaudit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblaudit` (
  `userid` int(11) DEFAULT NULL,
  `actionperformed` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `userid` (`userid`),
  CONSTRAINT `tblaudit_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblaudit`
--

LOCK TABLES `tblaudit` WRITE;
/*!40000 ALTER TABLE `tblaudit` DISABLE KEYS */;
INSERT INTO `tblaudit` VALUES (1002,'logged in','2019-03-23 12:18:33'),(1002,'logged in','2019-03-23 12:21:17'),(1002,'logged in','2019-03-23 12:25:50'),(1002,'logged in','2019-03-23 12:28:34'),(1002,'logged in','2019-03-23 12:35:02'),(1002,'logged in','2019-03-23 13:04:06'),(1002,'logged in','2019-03-23 13:05:28'),(1002,'logged in','2019-03-23 13:06:44'),(1002,'logged in','2019-03-23 13:09:35'),(1002,'logged in','2019-03-23 13:56:43'),(1002,'logged in','2019-03-23 14:00:19'),(1002,'logged in','2019-03-23 14:01:58'),(1002,'logged in','2019-03-23 14:07:09'),(1002,'logged in','2019-03-23 15:12:42'),(1002,'logged in','2019-03-23 15:14:41'),(1002,'logged in','2019-03-23 20:31:02'),(1002,'logged in','2019-03-23 20:32:33'),(1002,'logged in','2019-03-23 20:54:49'),(1002,'logged in','2019-03-23 20:56:24'),(1002,'logged in','2019-03-23 21:01:05'),(1002,'logged in','2019-03-23 21:02:42'),(1002,'logged in','2019-03-23 21:04:10'),(1002,'logged out','2019-03-23 21:05:30'),(1003,'logged in','2019-03-23 21:05:37'),(1003,'logged in','2019-03-23 21:07:10'),(1003,'logged in','2019-03-23 21:07:33'),(1003,'logged in','2019-03-23 21:27:30'),(1003,'logged in','2019-03-23 21:41:57'),(1003,'logged in','2019-03-23 21:52:31'),(1003,'logged in','2019-03-23 21:54:58'),(1003,'logged in','2019-03-23 21:56:09'),(1003,'logged in','2019-03-23 21:57:44'),(1003,'logged in','2019-03-23 22:00:33'),(1003,'logged in','2019-03-23 22:10:14'),(1003,'logged in','2019-03-23 22:16:05'),(1003,'logged out','2019-03-23 22:16:21'),(1003,'logged in','2019-03-23 22:19:20'),(1003,'logged out','2019-03-23 22:19:32'),(1003,'logged in','2019-03-23 22:19:49'),(1003,'logged out','2019-03-23 22:20:13'),(1003,'logged in','2019-03-23 22:27:38'),(1003,'logged in','2019-03-23 22:31:24'),(1003,'logged in','2019-03-23 22:31:54'),(1003,'logged in','2019-03-23 22:33:15'),(1001,'logged in','2019-03-23 22:34:51'),(1001,'logged in','2019-03-23 22:36:27'),(1001,'Inserted Service Record','2019-03-23 22:37:11'),(1003,'logged in','2019-03-23 22:38:49'),(1001,'logged in','2019-03-23 22:38:59'),(1002,'logged in','2019-03-23 22:40:24'),(1002,'logged in','2019-03-23 22:44:57'),(1002,'logged in','2019-03-23 22:46:45'),(1002,'logged in','2019-03-23 22:47:15'),(1002,'logged in','2019-03-23 22:51:29'),(1002,'logged in','2019-03-23 22:52:12'),(1002,'logged in','2019-03-23 22:53:46'),(1003,'logged in','2019-03-23 22:56:59'),(1003,'logged in','2019-03-24 13:38:36'),(1003,'logged in','2019-03-24 13:41:15'),(1003,'logged out','2019-03-24 13:41:47'),(1003,'logged in','2019-03-24 13:43:07'),(1003,'logged in','2019-03-24 13:47:40'),(1002,'logged in','2019-03-24 13:48:22'),(1003,'logged in','2019-03-24 13:52:51'),(1002,'logged in','2019-03-24 13:55:04'),(1002,'logged in','2019-03-24 13:57:22'),(1002,'logged in','2019-03-24 14:22:23'),(1002,'logged in','2019-03-24 14:26:07'),(1002,'logged in','2019-03-24 14:28:09'),(1003,'logged in','2019-03-24 14:28:57'),(1003,'logged out','2019-03-24 14:30:55'),(1003,'logged in','2019-03-24 14:31:18'),(1003,'logged out','2019-03-24 14:31:40'),(1002,'logged in','2019-03-24 14:31:45'),(1002,'logged in','2019-03-24 14:37:32'),(1002,'logged in','2019-03-24 14:40:57'),(1002,'logged in','2019-03-24 14:47:54'),(1002,'logged in','2019-03-24 14:49:20'),(1002,'logged out','2019-03-24 14:50:06'),(1003,'logged in','2019-03-24 14:50:24'),(1002,'logged in','2019-03-24 14:53:16'),(1002,'logged in','2019-03-24 17:10:01'),(1002,'logged in','2019-03-24 17:11:08'),(1003,'logged in','2019-03-24 17:11:48'),(1003,'logged out','2019-03-24 17:14:18'),(1002,'logged in','2019-03-24 17:17:43'),(1002,'logged in','2019-03-24 17:22:29'),(1002,'logged in','2019-03-24 17:29:43'),(1002,'logged in','2019-03-24 17:30:57'),(1002,'logged in','2019-03-24 17:33:41'),(1002,'logged in','2019-03-24 17:37:06'),(1002,'logged in','2019-03-24 17:38:16'),(1002,'logged in','2019-03-24 17:41:25'),(1002,'logged in','2019-03-24 17:43:39'),(1002,'logged in','2019-03-24 17:55:59'),(1002,'logged in','2019-03-24 17:59:16'),(1002,'logged in','2019-03-24 18:03:18'),(1002,'logged in','2019-03-24 18:07:54'),(1002,'logged in','2019-03-24 18:11:20'),(1002,'logged in','2019-03-24 18:12:08'),(1002,'logged in','2019-03-24 18:13:00'),(1002,'logged in','2019-03-24 18:25:46'),(1002,'logged in','2019-03-24 18:27:35'),(1002,'logged in','2019-03-24 18:35:55'),(1002,'logged in','2019-03-24 18:38:02'),(1002,'logged in','2019-03-24 18:38:36'),(1002,'logged in','2019-03-24 18:39:56'),(1002,'logged in','2019-03-24 18:40:25'),(1002,'logged in','2019-03-24 18:41:25'),(1002,'logged in','2019-03-24 18:42:02'),(1002,'logged in','2019-03-24 19:19:52'),(1002,'logged in','2019-03-24 19:47:48'),(1002,'logged in','2019-03-24 19:52:10'),(1002,'logged in','2019-03-24 19:56:48'),(1003,'logged in','2019-03-25 00:50:25'),(1003,'logged in','2019-03-25 00:56:06'),(1003,'logged in','2019-03-25 01:06:17'),(1003,'logged in','2019-03-25 01:08:14'),(1003,'logged in','2019-03-25 01:12:25'),(1003,'logged in','2019-03-25 01:13:16'),(1003,'logged in','2019-03-25 01:15:12'),(1003,'logged in','2019-03-25 01:15:37'),(1002,'logged in','2019-03-25 01:16:13'),(1003,'logged in','2019-03-25 01:16:24'),(1003,'logged in','2019-03-25 01:16:59'),(1003,'logged in','2019-03-25 01:17:19'),(1003,'logged in','2019-03-25 01:17:48'),(1003,'logged in','2019-03-25 01:20:31'),(1003,'logged out','2019-03-25 01:20:57'),(1002,'logged in','2019-03-25 01:25:12'),(1003,'logged in','2019-03-25 01:25:54'),(1003,'logged in','2019-03-25 01:42:28'),(1003,'logged in','2019-03-25 01:52:34'),(1003,'logged in','2019-03-25 01:54:24'),(1002,'logged in','2019-03-25 01:57:50'),(1003,'logged in','2019-03-25 01:58:37'),(1003,'logged in','2019-03-25 01:59:06'),(1003,'logged in','2019-03-25 01:59:33'),(1003,'logged in','2019-03-25 02:26:03'),(1003,'logged in','2019-03-25 02:29:09'),(1002,'logged in','2019-03-25 02:36:00'),(1003,'logged in','2019-03-25 02:36:27'),(1002,'logged in','2019-03-25 02:51:33'),(1003,'logged in','2019-03-25 03:37:04'),(1003,'logged in','2019-03-25 03:38:48'),(1003,'logged in','2019-03-25 03:45:42'),(1003,'logged in','2019-03-25 03:52:10'),(1003,'logged in','2019-03-25 03:52:34'),(1003,'logged in','2019-03-25 04:01:42'),(1003,'logged in','2019-03-25 04:05:52'),(1003,'logged in','2019-03-25 04:52:51'),(1002,'logged in','2019-03-25 04:54:24'),(1002,'logged in','2019-03-25 04:54:59'),(1003,'logged in','2019-03-25 04:55:43'),(1003,'logged in','2019-03-25 05:00:11'),(1002,'logged in','2019-03-25 05:06:35'),(1002,'logged in','2019-03-25 05:13:35'),(1002,'logged in','2019-03-25 05:14:36'),(1002,'logged in','2019-03-25 05:14:54'),(1002,'logged in','2019-03-25 05:20:12'),(1002,'logged in','2019-03-25 05:20:56'),(1003,'logged in','2019-03-25 05:21:52'),(1003,'logged in','2019-03-25 05:24:48'),(1003,'logged out','2019-03-25 05:25:20'),(1003,'logged in','2019-03-25 05:34:54'),(1003,'logged in','2019-03-25 05:37:19'),(1003,'logged out','2019-03-25 05:37:35'),(1002,'logged in','2019-03-25 07:48:09'),(1002,'logged in','2019-03-25 07:50:54'),(1002,'logged in','2019-03-25 07:53:19'),(1002,'logged in','2019-03-25 07:58:40'),(1002,'logged in','2019-03-25 07:59:25'),(1002,'logged in','2019-03-25 08:17:10'),(1002,'logged in','2019-03-25 08:17:47'),(1002,'logged in','2019-03-25 09:49:21'),(1002,'logged in','2019-03-25 09:51:29'),(1002,'logged in','2019-03-25 09:52:02'),(1002,'logged in','2019-03-25 10:11:54'),(1002,'logged in','2019-03-25 10:12:20'),(1002,'logged in','2019-03-25 10:17:26'),(1002,'logged in','2019-03-25 11:33:03'),(1003,'logged in','2019-03-25 11:40:19'),(1003,'logged out','2019-03-25 11:40:44'),(1003,'logged in','2019-03-25 11:49:24'),(1002,'logged in','2019-03-25 11:50:50'),(1003,'logged in','2019-03-25 11:50:59'),(1003,'logged out','2019-03-25 11:51:34'),(1002,'logged in','2019-03-25 11:52:49'),(1002,'logged in','2019-03-25 11:53:23'),(1002,'logged in','2019-03-25 11:55:09'),(1002,'logged in','2019-03-25 11:59:18'),(1002,'logged out','2019-03-25 12:13:48'),(1003,'logged in','2019-03-25 12:13:53'),(1002,'logged in','2019-03-25 13:04:47'),(1003,'logged in','2019-03-25 13:04:57'),(1003,'logged in','2019-03-25 13:06:19'),(1003,'logged in','2019-03-25 13:07:07'),(1003,'logged in','2019-03-25 13:14:36'),(1003,'logged in','2019-03-25 13:19:14'),(1003,'logged in','2019-03-25 13:32:21'),(1003,'logged in','2019-03-25 13:34:35'),(1003,'logged in','2019-03-25 13:35:27'),(1003,'logged in','2019-03-25 13:37:48'),(1003,'logged in','2019-03-25 13:40:15'),(1003,'logged in','2019-03-25 13:41:31'),(1003,'logged in','2019-03-25 13:42:31'),(1003,'logged in','2019-03-25 13:44:17'),(1003,'logged in','2019-03-25 13:46:28'),(1002,'logged in','2019-03-25 13:47:04'),(1003,'logged in','2019-03-25 13:47:15'),(1003,'logged in','2019-03-25 13:48:30'),(1003,'logged in','2019-03-25 13:50:03'),(1002,'logged in','2019-03-25 13:52:36'),(1003,'logged in','2019-03-25 13:52:51'),(1003,'logged in','2019-03-25 13:56:28'),(1003,'logged in','2019-03-25 13:58:56'),(1003,'logged in','2019-03-25 14:01:45'),(1003,'logged in','2019-03-25 14:02:47'),(1003,'logged in','2019-03-25 14:05:47'),(1003,'logged in','2019-03-25 14:09:44'),(1003,'logged in','2019-03-25 14:11:26'),(1003,'logged in','2019-03-25 14:13:10'),(1003,'logged in','2019-03-25 14:22:57'),(1003,'logged in','2019-03-25 14:24:27'),(1003,'logged out','2019-03-25 14:25:32'),(1002,'logged in','2019-03-25 14:25:36'),(1003,'logged in','2019-03-25 14:47:33'),(1002,'logged in','2019-03-25 15:21:21'),(1003,'logged in','2019-03-25 15:22:35'),(1002,'logged in','2019-03-25 15:26:00'),(1002,'logged out','2019-03-25 15:26:35'),(1003,'logged in','2019-03-25 15:26:42'),(1003,'logged out','2019-03-25 15:27:09'),(1002,'logged in','2019-03-25 15:33:53'),(1003,'logged in','2019-03-25 15:56:53'),(1002,'logged in','2019-03-25 15:57:50'),(1003,'logged out','2019-03-25 16:02:00'),(1003,'logged in','2019-03-25 16:02:09'),(1002,'logged in','2019-03-25 16:02:55'),(1003,'logged out','2019-03-25 16:04:25'),(1003,'logged in','2019-03-25 16:05:02'),(1002,'logged in','2019-03-25 16:09:46'),(1002,'logged in','2019-03-25 16:11:56'),(1002,'logged out','2019-03-25 16:14:09'),(1003,'logged in','2019-03-25 16:14:14'),(1003,'logged out','2019-03-25 16:20:53'),(1002,'logged in','2019-03-25 16:21:43'),(1002,'logged in','2019-03-25 22:56:46'),(1002,'logged out','2019-03-25 23:02:07'),(1002,'logged in','2019-03-25 23:02:12'),(1002,'logged out','2019-03-25 23:06:15'),(1003,'logged in','2019-03-25 23:18:29'),(1003,'logged out','2019-03-25 23:18:49'),(1003,'logged in','2019-03-25 23:19:11'),(1003,'logged out','2019-03-25 23:19:32'),(1003,'logged in','2019-03-25 23:21:08'),(1003,'logged out','2019-03-25 23:21:30'),(1003,'logged in','2019-03-25 23:24:50'),(1003,'logged out','2019-03-25 23:25:33'),(1003,'logged in','2019-03-25 23:26:36'),(1003,'logged out','2019-03-25 23:29:08'),(1003,'logged in','2019-03-25 23:34:29'),(1003,'logged out','2019-03-25 23:36:16'),(1003,'logged in','2019-03-25 23:44:25'),(1003,'logged out','2019-03-25 23:45:54'),(1003,'logged in','2019-03-26 00:03:57'),(1002,'logged in','2019-03-26 00:04:56'),(1002,'logged out','2019-03-26 00:05:14'),(1003,'logged in','2019-03-26 00:05:20'),(1003,'logged out','2019-03-26 00:07:27'),(1003,'logged in','2019-03-26 00:23:14'),(1003,'logged in','2019-03-26 00:23:40'),(1003,'logged out','2019-03-26 00:24:20'),(1003,'logged in','2019-03-26 00:25:53'),(1003,'logged out','2019-03-26 00:26:55'),(1002,'logged in','2019-03-26 00:32:26'),(1002,'Deleted a Patient Record','2019-03-26 00:34:25'),(1002,'logged out','2019-03-26 00:36:29'),(1002,'logged in','2019-03-26 00:36:33'),(1002,'logged out','2019-03-26 00:37:10'),(1003,'logged in','2019-03-26 00:37:32'),(1003,'logged out','2019-03-26 00:38:31'),(1002,'logged in','2019-03-26 00:38:57'),(1002,'logged out','2019-03-26 00:39:44'),(1002,'logged in','2019-03-26 00:40:37'),(1002,'Deleted a Patient Record','2019-03-26 00:41:15'),(1002,'logged out','2019-03-26 00:43:08'),(1003,'logged in','2019-03-26 00:43:21'),(1003,'logged out','2019-03-26 00:45:18'),(1003,'logged in','2019-03-26 00:49:32'),(1003,'logged out','2019-03-26 00:55:54'),(1003,'logged in','2019-03-26 00:56:12'),(1003,'logged out','2019-03-26 00:56:49'),(1002,'logged in','2019-03-26 02:33:45'),(1002,'logged out','2019-03-26 02:34:09'),(1002,'logged in','2019-03-26 02:35:46'),(1002,'logged out','2019-03-26 02:38:59'),(1002,'logged in','2019-03-26 02:43:57'),(1002,'logged out','2019-03-26 02:44:02'),(1002,'logged in','2019-03-26 02:44:29'),(1002,'logged out','2019-03-26 02:44:53'),(1002,'logged in','2019-03-26 02:45:45'),(1002,'logged out','2019-03-26 02:46:55'),(1003,'logged in','2019-03-26 02:47:03'),(1003,'logged out','2019-03-26 02:47:51'),(1003,'logged in','2019-03-26 02:48:03'),(1003,'logged out','2019-03-26 02:48:10'),(1003,'logged in','2019-03-26 02:53:01'),(1002,'logged in','2019-03-26 02:54:24'),(1002,'logged out','2019-03-26 02:55:16'),(1003,'logged in','2019-03-26 02:55:26'),(1003,'logged in','2019-03-26 03:15:01'),(1003,'logged out','2019-03-26 03:15:56'),(1003,'logged in','2019-03-26 03:16:20'),(1003,'logged out','2019-03-26 03:18:30'),(1003,'logged in','2019-03-26 03:18:35'),(1003,'logged out','2019-03-26 03:19:11'),(1003,'logged in','2019-03-26 03:34:19'),(1003,'logged out','2019-03-26 03:35:25'),(1003,'logged in','2019-03-26 03:37:46'),(1003,'logged out','2019-03-26 03:38:11'),(1002,'logged in','2019-03-26 03:38:20'),(1003,'logged in','2019-03-26 03:39:06'),(1002,'logged in','2019-03-26 03:43:44'),(1002,'logged out','2019-03-26 03:44:18'),(1003,'logged out','2019-03-26 03:44:32'),(1003,'logged in','2019-03-26 03:45:55'),(1003,'logged out','2019-03-26 03:46:04'),(1002,'logged in','2019-03-26 03:46:09'),(1002,'logged out','2019-03-26 03:57:03'),(1002,'logged in','2019-03-26 03:57:09'),(1002,'logged out','2019-03-26 03:57:20'),(1002,'logged in','2019-03-26 03:57:33'),(1002,'logged in','2019-03-26 04:00:11'),(1002,'logged out','2019-03-26 04:00:38'),(1002,'logged in','2019-03-26 04:03:37'),(1002,'logged out','2019-03-26 04:04:48'),(1002,'logged in','2019-03-26 04:05:40'),(1002,'logged out','2019-03-26 04:07:04'),(1003,'logged in','2019-03-26 04:15:44'),(1003,'logged out','2019-03-26 04:16:55'),(1002,'logged in','2019-03-26 04:20:04'),(1002,'logged out','2019-03-26 04:20:45'),(1003,'logged in','2019-03-26 04:21:27'),(1003,'logged out','2019-03-26 04:29:02'),(1002,'logged in','2019-03-26 04:29:14'),(1002,'logged in','2019-03-26 04:32:21'),(1002,'logged out','2019-03-26 04:32:37'),(1003,'logged in','2019-03-26 04:32:44'),(1003,'logged out','2019-03-26 04:33:40'),(1002,'logged in','2019-03-26 05:44:37'),(1002,'logged out','2019-03-26 05:48:03'),(1002,'logged in','2019-03-26 05:51:26'),(1002,'logged out','2019-03-26 05:52:14'),(1002,'logged in','2019-03-26 07:27:23'),(1002,'logged out','2019-03-26 07:27:59'),(1002,'logged in','2019-03-26 07:28:12'),(1002,'logged out','2019-03-26 07:28:43'),(1002,'logged in','2019-03-26 07:28:58'),(1002,'logged out','2019-03-26 07:29:48'),(1002,'logged in','2019-03-26 07:30:13'),(1002,'logged out','2019-03-26 07:30:56'),(1002,'logged in','2019-03-26 07:40:04'),(1002,'logged out','2019-03-26 07:41:02'),(1002,'logged in','2019-03-26 07:41:28'),(1002,'logged out','2019-03-26 07:42:12'),(1002,'logged in','2019-03-26 07:46:46'),(1002,'logged out','2019-03-26 07:47:48'),(1002,'logged in','2019-03-26 07:47:53'),(1002,'logged out','2019-03-26 07:48:33'),(1002,'logged in','2019-03-26 07:49:16'),(1002,'logged out','2019-03-26 07:49:50'),(1002,'logged in','2019-03-26 07:50:13'),(1002,'logged out','2019-03-26 07:50:57'),(1002,'logged in','2019-03-26 08:05:16'),(1002,'logged out','2019-03-26 08:07:05'),(1002,'logged in','2019-03-26 08:10:37'),(1002,'logged out','2019-03-26 08:11:34'),(1002,'logged in','2019-03-26 08:12:13'),(1002,'logged out','2019-03-26 08:12:54'),(1002,'logged in','2019-03-26 08:14:14'),(1002,'logged in','2019-03-26 08:15:54'),(1002,'logged out','2019-03-26 08:16:31'),(1002,'logged in','2019-03-26 08:17:22'),(1002,'logged out','2019-03-26 08:18:02'),(1002,'logged in','2019-03-26 08:18:43'),(1002,'logged out','2019-03-26 08:19:14'),(1002,'logged in','2019-03-26 08:20:03'),(1002,'logged out','2019-03-26 08:20:14'),(1002,'logged in','2019-03-26 08:20:33'),(1002,'logged out','2019-03-26 08:21:54'),(1002,'logged in','2019-03-26 08:22:17'),(1002,'logged out','2019-03-26 08:22:54'),(1002,'logged in','2019-03-26 08:23:49'),(1003,'logged in','2019-03-26 08:25:21'),(1002,'logged in','2019-03-26 08:26:24'),(1003,'logged out','2019-03-26 08:28:47'),(1002,'logged in','2019-03-26 08:30:59'),(1003,'logged in','2019-03-26 08:32:12'),(1003,'logged out','2019-03-26 08:37:16'),(1002,'logged out','2019-03-26 08:37:33'),(1002,'logged in','2019-03-26 08:39:50'),(1002,'logged out','2019-03-26 08:40:20'),(1002,'logged in','2019-03-26 08:41:10'),(1002,'logged out','2019-03-26 08:41:41'),(1002,'logged in','2019-03-26 08:41:54'),(1002,'logged out','2019-03-26 08:45:50'),(1002,'logged in','2019-03-26 08:45:55'),(1002,'logged out','2019-03-26 08:49:33'),(1002,'logged in','2019-03-26 08:55:56'),(1002,'logged out','2019-03-26 08:56:24'),(1002,'logged in','2019-03-26 08:58:07'),(1002,'logged out','2019-03-26 08:59:29'),(1002,'logged in','2019-03-26 09:00:25'),(1002,'logged out','2019-03-26 09:00:56'),(1002,'logged in','2019-03-26 09:01:39'),(1002,'logged out','2019-03-26 09:05:23'),(1002,'logged in','2019-03-26 11:03:43'),(1002,'logged out','2019-03-26 11:15:37'),(1002,'logged in','2019-03-26 13:58:26'),(1002,'logged out','2019-03-26 13:59:21'),(1002,'logged in','2019-03-26 13:59:35'),(1002,'logged out','2019-03-26 14:00:31'),(1002,'logged in','2019-03-26 14:03:59'),(1002,'logged out','2019-03-26 14:05:55'),(1003,'logged in','2019-03-26 14:06:03'),(1003,'logged in','2019-03-26 14:07:44'),(1003,'logged in','2019-03-26 14:08:48'),(1003,'logged out','2019-03-26 14:17:42'),(1003,'logged in','2019-03-26 14:24:12'),(1003,'logged out','2019-03-26 20:49:58'),(1003,'logged in','2019-03-26 20:54:53'),(1003,'logged out','2019-03-26 20:55:46'),(1002,'logged in','2019-03-26 20:57:55'),(1002,'logged out','2019-03-26 21:34:32'),(1003,'logged in','2019-03-26 21:34:38'),(1003,'logged out','2019-03-26 21:47:45'),(1002,'logged in','2019-03-26 22:01:01'),(1002,'logged in','2019-03-26 22:18:55'),(1002,'logged out','2019-03-26 22:22:27'),(1002,'logged in','2019-03-26 22:27:00'),(1002,'logged out','2019-03-26 22:35:19'),(1002,'logged in','2019-03-26 23:27:53'),(1002,'logged out','2019-03-26 23:28:24'),(1002,'logged in','2019-03-26 23:29:08'),(1002,'logged out','2019-03-26 23:29:29'),(1002,'logged in','2019-03-26 23:30:38'),(1002,'logged out','2019-03-26 23:31:03'),(1002,'logged in','2019-03-26 23:33:01'),(1002,'logged out','2019-03-26 23:34:09'),(1002,'logged in','2019-03-26 23:35:31'),(1002,'logged out','2019-03-26 23:36:48'),(1002,'logged in','2019-03-26 23:38:27'),(1002,'logged out','2019-03-26 23:48:38'),(1002,'logged in','2019-03-26 23:48:49'),(1002,'logged out','2019-03-26 23:50:00'),(1003,'logged in','2019-03-27 00:03:24'),(1003,'logged out','2019-03-27 00:06:27'),(1003,'logged in','2019-03-27 00:06:33'),(1003,'logged out','2019-03-27 00:07:16'),(1003,'logged in','2019-03-27 00:24:35'),(1003,'logged out','2019-03-27 00:25:09'),(1002,'logged in','2019-03-27 00:25:54'),(1002,'logged out','2019-03-27 00:27:37'),(1003,'logged in','2019-03-27 00:27:41'),(1003,'logged out','2019-03-27 00:29:33'),(1002,'logged in','2019-03-27 02:45:03'),(1002,'logged out','2019-03-27 02:47:14'),(1003,'logged in','2019-03-27 02:47:19'),(1003,'logged out','2019-03-27 02:48:10'),(1002,'logged in','2019-03-27 05:47:08'),(1002,'logged out','2019-03-27 05:48:40'),(1002,'logged in','2019-03-27 05:52:02'),(1002,'logged out','2019-03-27 05:52:45'),(1002,'logged in','2019-03-27 05:53:40'),(1002,'logged out','2019-03-27 05:54:03'),(1002,'logged in','2019-03-27 05:55:51'),(1002,'logged out','2019-03-27 05:56:26'),(1002,'logged in','2019-03-27 05:59:09'),(1002,'logged in','2019-03-27 06:00:58'),(1002,'Updated a Patient Record','2019-03-27 06:01:44'),(1002,'Updated a Patient Record','2019-03-27 06:02:08'),(1002,'Updated a Patient Record','2019-03-27 06:02:14'),(1002,'Updated a Patient Record','2019-03-27 06:02:19'),(1002,'Updated a Patient Record','2019-03-27 06:02:23'),(1002,'Updated a Patient Record','2019-03-27 06:02:27'),(1002,'Updated a Patient Record','2019-03-27 06:02:30'),(1002,'Updated a Patient Record','2019-03-27 06:02:33'),(1002,'Updated a Patient Record','2019-03-27 06:02:37'),(1002,'Updated a Patient Record','2019-03-27 06:02:42'),(1002,'Updated a Patient Record','2019-03-27 06:02:46'),(1002,'Updated a Patient Record','2019-03-27 06:02:50'),(1002,'Updated a Patient Record','2019-03-27 06:02:55'),(1002,'Updated a Patient Record','2019-03-27 06:03:01'),(1002,'Updated a Patient Record','2019-03-27 06:07:48'),(1002,'logged out','2019-03-27 06:08:25'),(1002,'logged in','2019-03-27 06:14:20'),(1002,'logged out','2019-03-27 06:16:18'),(1002,'logged in','2019-03-27 06:20:57'),(1002,'logged out','2019-03-27 06:21:04'),(1002,'logged in','2019-03-27 06:21:19'),(1002,'logged out','2019-03-27 06:22:51'),(1002,'logged in','2019-03-27 06:27:37'),(1002,'logged out','2019-03-27 06:29:26'),(1002,'logged in','2019-03-27 06:30:19'),(1002,'logged out','2019-03-27 06:33:01'),(1002,'logged in','2019-03-27 06:36:46'),(1002,'logged out','2019-03-27 06:37:10'),(1002,'logged in','2019-03-27 06:51:35'),(1002,'Deleted a Patient Record','2019-03-27 06:51:51'),(1002,'logged out','2019-03-27 06:52:03'),(1002,'logged in','2019-03-27 06:54:12'),(1002,'logged in','2019-03-27 06:57:33'),(1002,'logged out','2019-03-27 06:58:07'),(1002,'logged in','2019-03-27 06:59:25'),(1002,'logged in','2019-03-27 07:02:28'),(1002,'logged out','2019-03-27 07:09:15'),(1002,'logged in','2019-03-27 08:53:08'),(1002,'Registered a New Patient','2019-03-27 08:54:31'),(1002,'Updated a Patient Record','2019-03-27 08:55:54'),(1002,'logged out','2019-03-27 08:58:48'),(1003,'logged in','2019-03-27 08:58:53'),(1003,'logged out','2019-03-27 09:02:16'),(1002,'logged in','2019-03-27 09:04:12'),(1002,'logged out','2019-03-27 09:13:34'),(1002,'logged in','2019-03-27 09:14:00'),(1002,'logged out','2019-03-27 09:14:17'),(1002,'logged in','2019-03-27 09:26:47'),(1002,'logged out','2019-03-27 09:27:37'),(1003,'logged in','2019-03-27 09:27:42'),(1003,'logged out','2019-03-27 09:29:03'),(1002,'logged in','2019-03-27 09:35:04'),(1002,'logged out','2019-03-27 09:35:09'),(1003,'logged in','2019-03-27 09:35:14'),(1003,'logged out','2019-03-27 09:37:49'),(1003,'logged in','2019-03-27 10:29:54'),(1003,'logged out','2019-03-27 10:30:54'),(1003,'logged in','2019-03-27 11:50:51'),(1003,'logged in','2019-03-27 11:52:02'),(1003,'logged out','2019-03-27 11:54:06'),(1003,'logged in','2019-03-27 11:54:39'),(1003,'logged out','2019-03-27 11:55:29'),(1003,'logged in','2019-03-27 11:57:00'),(1003,'logged out','2019-03-27 12:00:54'),(1003,'logged in','2019-03-27 12:02:27'),(1003,'logged out','2019-03-27 12:03:27'),(1003,'logged in','2019-03-27 14:16:49'),(1003,'logged out','2019-03-27 14:57:33'),(1003,'logged in','2019-03-27 15:01:08'),(1003,'logged in','2019-03-27 15:05:59'),(1003,'logged out','2019-03-27 15:06:27'),(1003,'logged in','2019-03-27 15:18:23'),(1003,'logged out','2019-03-27 15:19:30'),(1003,'logged in','2019-03-27 15:21:57'),(1003,'logged out','2019-03-27 15:22:21'),(1002,'logged in','2019-03-27 16:01:55'),(1002,'logged out','2019-03-27 16:04:08'),(1002,'logged in','2019-03-27 16:17:12'),(1002,'logged out','2019-03-27 16:17:54'),(1002,'logged in','2019-03-27 16:21:01'),(1002,'logged out','2019-03-27 16:22:34'),(1002,'logged in','2019-03-27 16:34:00'),(1002,'logged out','2019-03-27 16:37:06'),(1003,'logged in','2019-03-27 16:48:58'),(1003,'logged out','2019-03-27 16:52:02'),(1002,'logged in','2019-03-27 16:53:58'),(1002,'logged out','2019-03-27 16:54:11'),(1003,'logged in','2019-03-27 16:54:15'),(1003,'logged out','2019-03-27 16:55:39'),(1002,'logged in','2019-03-28 06:09:25'),(1002,'logged out','2019-03-28 06:11:09'),(1002,'logged in','2019-03-28 06:12:52'),(1002,'logged out','2019-03-28 06:14:13'),(1002,'logged in','2019-03-28 06:14:49'),(1002,'logged out','2019-03-28 06:15:29'),(1003,'logged in','2019-03-28 06:15:47'),(1002,'logged in','2019-03-28 06:18:29'),(1002,'logged out','2019-03-28 06:18:48'),(1003,'logged in','2019-03-28 06:18:54'),(1003,'logged out','2019-03-28 06:27:17'),(1002,'logged in','2019-03-28 07:26:10'),(1002,'Deleted a Patient Record','2019-03-28 07:35:57'),(1002,'logged out','2019-03-28 07:37:46'),(1002,'logged in','2019-03-28 07:38:02'),(1002,'logged out','2019-03-28 07:38:10'),(1002,'logged in','2019-03-28 07:38:44'),(1002,'Updated Medicine Record','2019-03-28 07:40:20'),(1002,'logged out','2019-03-28 07:41:02'),(1003,'logged in','2019-03-28 07:41:30'),(1003,'logged out','2019-03-28 07:41:43'),(1003,'logged in','2019-03-28 07:42:58'),(1003,'logged out','2019-03-28 07:43:20'),(1002,'logged in','2019-03-28 07:43:45'),(1002,'logged out','2019-03-28 07:44:13'),(1003,'logged in','2019-03-28 07:44:23'),(1003,'logged out','2019-03-28 07:45:21'),(1002,'logged in','2019-03-28 07:50:41'),(1002,'logged out','2019-03-28 07:51:19'),(1002,'logged in','2019-03-28 07:52:09'),(1002,'logged out','2019-03-28 07:52:32'),(1002,'logged in','2019-03-28 07:53:21'),(1002,'logged out','2019-03-28 07:53:44'),(1002,'logged in','2019-03-28 09:23:20'),(1002,'logged out','2019-03-28 09:25:48'),(1002,'logged in','2019-03-28 09:29:17'),(1002,'logged out','2019-03-28 09:29:39'),(1003,'logged in','2019-03-28 09:29:48'),(1003,'logged out','2019-03-28 09:30:03'),(1002,'logged in','2019-03-28 09:33:19'),(1002,'logged in','2019-03-28 09:52:14'),(1002,'logged out','2019-03-28 09:53:37'),(1002,'logged in','2019-03-28 09:54:28'),(1002,'logged out','2019-03-28 09:58:51'),(1002,'logged in','2019-03-28 09:59:18'),(1002,'logged out','2019-03-28 10:01:41'),(1002,'logged in','2019-03-28 10:21:03'),(1003,'logged in','2019-03-28 10:26:03'),(1001,'logged in','2019-03-28 10:33:11'),(1001,'Inserted Service Record','2019-03-28 10:33:30'),(1002,'logged in','2019-03-28 10:35:31'),(1003,'logged out','2019-03-28 10:37:35'),(1002,'logged in','2019-03-29 09:54:48'),(1002,'logged out','2019-03-29 09:55:52'),(1003,'logged in','2019-03-29 09:55:58'),(1003,'logged in','2019-03-29 09:57:09'),(1003,'logged out','2019-03-29 09:57:26'),(1002,'logged in','2019-03-29 09:57:38'),(1002,'logged out','2019-03-29 09:58:14'),(1003,'logged in','2019-03-29 09:58:21'),(1003,'logged in','2019-03-29 10:10:17'),(1003,'logged in','2019-03-29 10:13:23'),(1003,'logged out','2019-03-29 10:14:18'),(1002,'logged in','2019-03-30 02:39:31'),(1002,'logged out','2019-03-30 02:44:11'),(1002,'logged in','2019-03-30 02:57:57'),(1002,'logged out','2019-03-30 02:58:25'),(1003,'logged in','2019-03-30 02:58:32'),(1003,'logged out','2019-03-30 02:59:05'),(1003,'logged in','2019-04-01 03:29:39'),(1003,'logged in','2019-04-01 03:30:18'),(1003,'logged out','2019-04-01 03:30:56'),(1003,'logged in','2019-04-01 03:47:15'),(1003,'logged out','2019-04-01 03:48:44'),(1003,'logged in','2019-04-01 14:57:19'),(1003,'logged out','2019-04-01 14:57:30'),(1002,'logged in','2019-04-01 14:57:34'),(1002,'Updated Schedule','2019-04-01 15:00:16'),(1002,'Updated Schedule','2019-04-01 15:01:34'),(1002,'logged out','2019-04-01 15:01:40'),(1001,'logged in','2019-04-01 15:01:44'),(1001,'Updated User Account','2019-04-01 15:02:26'),(1001,'logged out','2019-04-01 15:02:50'),(1002,'logged in','2019-04-01 15:02:56'),(1002,'Updated Schedule','2019-04-01 15:04:21'),(1002,'Updated Schedule','2019-04-01 15:05:16'),(1002,'Updated Schedule','2019-04-01 15:06:01'),(1002,'Updated Schedule','2019-04-01 15:06:33'),(1002,'Updated Schedule','2019-04-01 15:07:02'),(1002,'logged out','2019-04-01 15:07:32'),(1002,'logged in','2019-04-01 15:11:08'),(1002,'logged out','2019-04-01 15:11:26'),(1001,'logged in','2019-04-01 15:11:39'),(1001,'Updated User Account','2019-04-01 15:13:06'),(1001,'logged out','2019-04-01 15:15:13'),(1001,'logged in','2019-04-01 15:15:27'),(1001,'Created a New User Account','2019-04-01 15:16:25'),(1001,'Updated User Account','2019-04-01 15:16:30'),(1001,'logged out','2019-04-01 15:16:34'),(1001,'logged in','2019-04-01 15:16:52'),(1001,'Updated User Account','2019-04-01 15:17:00'),(1001,'logged out','2019-04-01 15:17:05'),(1004,'logged in','2019-04-01 15:17:11'),(1004,'logged out','2019-04-01 15:17:18'),(1002,'logged in','2019-04-01 15:18:04'),(1002,'Updated Schedule','2019-04-01 15:18:36'),(1002,'logged out','2019-04-01 15:24:45'),(1002,'logged in','2019-04-01 15:31:52'),(1002,'logged out','2019-04-01 15:35:10'),(1002,'logged in','2019-04-01 15:38:43'),(1002,'logged in','2019-04-01 15:39:48'),(1002,'logged in','2019-04-01 15:40:27'),(1002,'logged in','2019-04-01 15:42:23'),(1002,'logged out','2019-04-01 15:42:59'),(1002,'logged in','2019-04-01 15:44:42'),(1002,'logged out','2019-04-01 15:45:00'),(1002,'logged in','2019-04-01 15:45:16'),(1002,'logged out','2019-04-01 15:45:24'),(1002,'logged in','2019-04-01 15:46:06'),(1002,'logged out','2019-04-01 15:46:59'),(1002,'logged in','2019-04-01 15:47:55'),(1002,'logged out','2019-04-01 15:52:58'),(1002,'logged in','2019-04-01 17:13:08'),(1002,'logged out','2019-04-01 17:13:58'),(1002,'logged in','2019-04-01 17:17:36'),(1002,'Updated Schedule','2019-04-01 17:21:55'),(1002,'logged out','2019-04-01 17:28:56'),(1002,'logged in','2019-04-01 17:31:04'),(1002,'logged in','2019-04-01 17:32:38'),(1002,'logged out','2019-04-01 17:33:07'),(1002,'logged in','2019-04-01 22:20:21'),(1002,'logged in','2019-04-01 22:22:08'),(1002,'logged out','2019-04-01 22:30:19'),(1002,'logged in','2019-04-01 22:35:55'),(1002,'logged in','2019-04-01 22:42:46'),(1002,'logged in','2019-04-01 22:43:57'),(1002,'logged out','2019-04-01 22:48:06'),(1003,'logged in','2019-04-01 22:49:41'),(1003,'logged out','2019-04-01 22:50:38'),(1003,'logged in','2019-04-01 22:57:56'),(1003,'logged out','2019-04-01 23:02:50'),(1003,'logged in','2019-04-01 23:04:31'),(1003,'logged in','2019-04-01 23:39:11'),(1003,'logged out','2019-04-01 23:45:24'),(1003,'logged in','2019-04-01 23:47:54'),(1003,'logged out','2019-04-01 23:49:33'),(1001,'logged in','2019-04-01 23:51:37'),(1001,'logged in','2019-04-01 23:55:37'),(1001,'logged in','2019-04-01 23:56:02'),(1001,'logged in','2019-04-01 23:58:33'),(1001,'logged out','2019-04-01 23:59:01'),(1002,'logged in','2019-04-02 10:32:32'),(1002,'logged in','2019-04-02 14:14:23'),(1002,'logged out','2019-04-02 14:44:38'),(1003,'logged in','2019-04-02 14:56:52'),(1003,'logged out','2019-04-02 14:57:00'),(1002,'logged in','2019-04-02 15:05:19'),(1002,'logged out','2019-04-02 15:08:44'),(1002,'logged in','2019-04-02 15:11:20'),(1002,'logged in','2019-04-02 15:12:59'),(1002,'logged in','2019-04-02 15:13:42'),(1002,'logged in','2019-04-02 15:20:29'),(1003,'logged in','2019-04-02 15:53:58'),(1003,'logged out','2019-04-02 16:01:15'),(1003,'logged in','2019-04-02 16:01:53'),(1003,'logged out','2019-04-02 17:25:13'),(1002,'logged in','2019-04-02 17:25:17'),(1002,'logged out','2019-04-02 17:29:54'),(1002,'logged in','2019-04-02 18:00:41'),(1002,'logged out','2019-04-02 18:02:27'),(1002,'logged in','2019-04-04 11:11:24'),(1002,'logged out','2019-04-04 11:11:54'),(1003,'logged in','2019-04-04 11:12:02'),(1003,'logged out','2019-04-04 11:12:36'),(1003,'logged in','2019-04-05 06:40:25'),(1003,'logged out','2019-04-05 06:45:22'),(1003,'logged in','2019-04-05 06:52:31'),(1003,'logged out','2019-04-05 06:53:53'),(1003,'logged in','2019-04-05 08:25:03'),(1003,'logged out','2019-04-05 08:26:55'),(1003,'logged in','2019-04-05 08:27:20'),(1003,'logged out','2019-04-05 08:28:36');
/*!40000 ALTER TABLE `tblaudit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbilling`
--

DROP TABLE IF EXISTS `tblbilling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblbilling` (
  `billingid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `service` varchar(100) DEFAULT NULL,
  `totalcharge` decimal(20,2) DEFAULT NULL,
  `cash` decimal(20,2) DEFAULT NULL,
  `chaange` decimal(20,2) DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`billingid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblbilling_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbilling`
--

LOCK TABLES `tblbilling` WRITE;
/*!40000 ALTER TABLE `tblbilling` DISABLE KEYS */;
INSERT INTO `tblbilling` VALUES (1000,1001,'New Born Screening',650.00,700.00,50.00,'2019-02-21 00:38:08'),(1001,1001,'Prenatal Checkup Package',650.00,700.00,50.00,'2019-03-04 01:20:35'),(1002,1009,'Prenatal Checkup Package',650.00,800.00,150.00,'2019-03-16 07:55:51'),(1003,1001,'Prenatal Checkup Package',650.00,800.00,150.00,'2019-03-16 12:42:26'),(1004,1009,'Prenatal Checkup Package',650.00,800.00,150.00,'2019-03-19 12:52:56'),(1005,1009,'Prenatal Checkup Package',650.00,800.00,150.00,'2019-03-19 13:07:01'),(1006,1009,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 13:14:07'),(1007,1009,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 13:16:12'),(1008,1009,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 13:18:29'),(1009,1009,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 13:19:25'),(1010,1001,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 13:20:48'),(1011,1001,'Prenatal Checkup Package',650.00,1000.00,350.00,'2019-03-19 13:22:05'),(1012,1001,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 13:22:33'),(1013,1001,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 13:23:57'),(1014,1009,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 13:25:47'),(1015,1009,'Prenatal Checkup Package',650.00,700.00,50.00,'2019-03-19 15:31:16'),(1016,1009,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-19 17:49:16'),(1017,1009,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-20 10:36:36'),(1018,1001,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-20 12:54:18'),(1019,1009,'Prenatal Checkup Package',650.00,900.00,250.00,'2019-03-25 11:59:37'),(1020,1001,'Prenatal Package',750.00,1000.00,250.00,'2019-03-28 10:35:59'),(1021,1009,'Prenatal Checkup Package',650.00,700.00,50.00,'2019-04-02 18:01:09');
/*!40000 ALTER TABLE `tblbilling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblbillpat`
--

DROP TABLE IF EXISTS `tblbillpat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblbillpat` (
  `billpatid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `service` varchar(100) DEFAULT NULL,
  `totalcharge` decimal(20,2) DEFAULT NULL,
  PRIMARY KEY (`billpatid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblbillpat_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblbillpat`
--

LOCK TABLES `tblbillpat` WRITE;
/*!40000 ALTER TABLE `tblbillpat` DISABLE KEYS */;
INSERT INTO `tblbillpat` VALUES (1000,1001,'asd',650.00),(1003,1001,'Prenatal Package',650.00);
/*!40000 ALTER TABLE `tblbillpat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblchildeval`
--

DROP TABLE IF EXISTS `tblchildeval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblchildeval` (
  `childevalid` int(11) NOT NULL,
  `race` varchar(50) DEFAULT NULL,
  `gdlastname` varchar(30) DEFAULT NULL,
  `gdfirstname` varchar(30) DEFAULT NULL,
  `gdmiddlename` varchar(50) DEFAULT NULL,
  `gdaddno` varchar(100) DEFAULT NULL,
  `gdaddst` varchar(100) DEFAULT NULL,
  `gdaddbrgy` varchar(100) DEFAULT NULL,
  `gdaddcity` varchar(100) DEFAULT NULL,
  `gdaddstate` varchar(100) DEFAULT NULL,
  `gdaddzip` varchar(100) DEFAULT NULL,
  `gdlandline` varchar(30) DEFAULT NULL,
  `gdcellno` varchar(30) DEFAULT NULL,
  `patientid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`childevalid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblchildeval_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblchildeval`
--

LOCK TABLES `tblchildeval` WRITE;
/*!40000 ALTER TABLE `tblchildeval` DISABLE KEYS */;
INSERT INTO `tblchildeval` VALUES (1000,'Asian','Lorenzo','Venice','Escudero','asd','asd','asd','sad','ads','asda',NULL,NULL,1001,'2019-02-04'),(1004,'Asian','Cabardo','Mike','\r\nEstrada','28','Santol','San Miguel','Taguig','NCR','1629','488-1918','095664568542',1002,'2019-03-20'),(1005,'Asian','Cabardo','Anthony','Estrada','12','Santol','San Miguel','Taguig','Manila','1620','645-4856','0956455254',1004,'2019-03-20'),(1006,'Asian','Martinez','Anthony ','\r\nEscalante','23','Santol','San Miguel','Pasig','Manila','1256','645-7342','0967345633',1011,'2019-03-20'),(1007,'Asian','Lorenzo, Michael Esduero',NULL,NULL,'asd','asd','asdfa','asd','asd','asd','9099909','0999909',1005,'2019-03-28'),(1008,'Asian','Dela Cruz, Juan',NULL,NULL,'26','asdasd','asd','asd','asd','0622','648-4522','0999099',1007,'2019-03-28');
/*!40000 ALTER TABLE `tblchildeval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbldispense`
--

DROP TABLE IF EXISTS `tbldispense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbldispense` (
  `dispenseid` int(11) NOT NULL,
  `medicine` varchar(200) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastname` varchar(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `middlename` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`dispenseid`),
  KEY `userid` (`userid`),
  CONSTRAINT `tbldispense_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbldispense`
--

LOCK TABLES `tbldispense` WRITE;
/*!40000 ALTER TABLE `tbldispense` DISABLE KEYS */;
INSERT INTO `tbldispense` VALUES (1001,'Antihistamine - OTC - 12',1002,'2019-03-13 08:38:39','Ramos','Mariano','Angeles'),(1002,'Metropolol - Maintenance - 21',1002,'2019-03-16 03:05:28','dela Vega','Shirley','Lorenzo'),(1003,'Paracetamol - OTC - 10',1002,'2019-03-17 16:13:33','mamp','mamp','\r\nmamp'),(1004,'Antihistamine - OTC - 10, Ibuprofen - OTC - 10',1002,'2019-03-18 07:49:18','martinez','asd','asd'),(1005,'',1002,'2019-03-18 10:17:44','dela Vega','Shirley','Lorenzo'),(1006,'Paracetamol - OTC - 10',1002,'2019-03-18 10:20:45','asd','asd','\r\nasd'),(1007,'Metropolol - Maintenance - 25',1002,'2019-03-19 01:36:49','dela Vega','Shirley','Lorenzo'),(1008,'Biogesic - OTC - 15, Acetaminophen - OTC - 10',1002,'2019-03-20 12:47:24','asdvgv','asd','asd'),(1009,'Antihistamine - OTC - 20',1002,'2019-03-21 17:43:57','Lorenzo','Vanz','Czeray'),(1010,'Biogesic - OTC - 37',1002,'2019-03-21 20:16:22','dela Vega','Shirley','Lorenzo'),(1011,'Metformin - Maintenance - 12',1002,'2019-03-25 02:58:11','dela Vega','Shirley','Lorenzo'),(1012,'Metformin - Maintenance - 12',1002,'2019-03-25 09:53:03','dela Vega','Shirley','Lorenzo'),(1013,'Metformin - Maintenance - 12',1002,'2019-03-25 09:53:25','dela Vega','Shirley','Lorenzo'),(1014,'Amlodipine - Maintenance - 12',1002,'2019-03-25 09:54:00','dela Vega','Shirley','Lorenzo'),(1015,'Antihistamine - OTC - 12',1002,'2019-03-25 10:02:48','asd','as','asd'),(1016,'Antihistamine - OTC - 8',1002,'2019-03-25 10:03:48','asd','asd','asd'),(1017,'Antihistamine - OTC - 12',1002,'2019-03-25 11:38:25','dela Vega','Shirley','Lorenzo'),(1018,'neozep - OTC - 12',1002,'2019-03-25 23:04:53','lorenzo','vashti','\r\nescudero'),(1019,'Paracetamol - OTC - 60',1002,'2019-03-28 09:55:08','asd','asd','asd'),(1020,'Paracetamol - OTC - 42',1002,'2019-03-28 09:56:03','asd','asd','asd'),(1021,'Paracetamol - OTC - 10',1002,'2019-03-28 09:58:23','aaa','aaa','aaa'),(1022,'Paracetamol - OTC - 8',1002,'2019-03-28 10:00:27','xa','ax','\r\nax'),(1023,'Paracetamol - OTC - 12',1002,'2019-03-30 02:41:26','aaa','aaa','\r\naaa'),(1024,'Paracetamol - OTC - 12',1002,'2019-04-01 17:27:35','asd','asd','\r\nsd'),(1025,'Paracetamol - OTC - 12',1002,'2019-04-01 17:27:55','asd','sd','asd');
/*!40000 ALTER TABLE `tbldispense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbldisppopulate`
--

DROP TABLE IF EXISTS `tbldisppopulate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbldisppopulate` (
  `medicine` varchar(200) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `quantity` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbldisppopulate`
--

LOCK TABLES `tbldisppopulate` WRITE;
/*!40000 ALTER TABLE `tbldisppopulate` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbldisppopulate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblflcheckup`
--

DROP TABLE IF EXISTS `tblflcheckup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblflcheckup` (
  `flcheckupid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `program` varchar(100) DEFAULT NULL,
  `preliminary_date` date DEFAULT NULL,
  `additionalinfo` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`flcheckupid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblflcheckup_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblflcheckup`
--

LOCK TABLES `tblflcheckup` WRITE;
/*!40000 ALTER TABLE `tblflcheckup` DISABLE KEYS */;
INSERT INTO `tblflcheckup` VALUES (1000,1001,'asd','2019-02-27',NULL),(1003,1009,'Prenatal Checkup','2019-04-08','ultrasound');
/*!40000 ALTER TABLE `tblflcheckup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblimmpopulate`
--

DROP TABLE IF EXISTS `tblimmpopulate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblimmpopulate` (
  `vaccine` varchar(200) DEFAULT NULL,
  `dosage` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblimmpopulate`
--

LOCK TABLES `tblimmpopulate` WRITE;
/*!40000 ALTER TABLE `tblimmpopulate` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblimmpopulate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmedicine`
--

DROP TABLE IF EXISTS `tblmedicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmedicine` (
  `medid` int(11) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `medname` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`medid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmedicine`
--

LOCK TABLES `tblmedicine` WRITE;
/*!40000 ALTER TABLE `tblmedicine` DISABLE KEYS */;
INSERT INTO `tblmedicine` VALUES (1001,'Maintenance','Losartan','For High Blood Pressure'),(1002,'Maintenance','Amlodipine','For High Blood Pressure'),(1003,'Maintenance','Metropolol','For High Blood Pressure'),(1004,'Maintenance','Metformin','For High Blood Sugar'),(1005,'OTC','Paracetamol','For Fever'),(1007,'Vaccination','BCG','For Tuberculosis'),(1008,'Vaccination','DPT','For Diptheria, Pertussis and Tetanus'),(1009,'Vaccination','OPV','For Polio'),(1010,'Vaccination','Measles','For Measles'),(1011,'Vaccination','Hepa B','For Hepatitis B'),(1012,'OTC','Antihistamine','For Allergies'),(1013,'OTC','Ibuprofen','Pain Killer'),(1014,'OTC','Acetaminophen','Pain Killer'),(1015,'OTC','Antibiotic','wala lang'),(1016,'OTC','Loratadine','For Allergies'),(1017,'OTC','Ascorbic Acid','Vitamins'),(1018,'OTC','Biogesic','50 mg'),(1019,'OTC','neozep','for common colds');
/*!40000 ALTER TABLE `tblmedicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmedinfo`
--

DROP TABLE IF EXISTS `tblmedinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmedinfo` (
  `medinfoid` int(11) NOT NULL,
  `q1` varchar(500) DEFAULT NULL,
  `q2` varchar(300) DEFAULT NULL,
  `q3` varchar(300) DEFAULT NULL,
  `q4` varchar(50) DEFAULT NULL,
  `q5` varchar(50) DEFAULT NULL,
  `q6` varchar(50) DEFAULT NULL,
  `q7` varchar(50) DEFAULT NULL,
  `q8` varchar(50) DEFAULT NULL,
  `q9` varchar(50) DEFAULT NULL,
  `q10` varchar(50) DEFAULT NULL,
  `q11` varchar(50) DEFAULT NULL,
  `q12` varchar(50) DEFAULT NULL,
  `q13` varchar(50) DEFAULT NULL,
  `q14` varchar(50) DEFAULT NULL,
  `q15` varchar(50) DEFAULT NULL,
  `q16` varchar(300) DEFAULT NULL,
  `q17` varchar(500) DEFAULT NULL,
  `q18` varchar(300) DEFAULT NULL,
  `patientid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`medinfoid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblmedinfo_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmedinfo`
--

LOCK TABLES `tblmedinfo` WRITE;
/*!40000 ALTER TABLE `tblmedinfo` DISABLE KEYS */;
INSERT INTO `tblmedinfo` VALUES (1001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-03-20'),(1002,'Antihistamine   20 mg   By Mouth(PO)   Daily','Shellfish   Skin Rashes','Mercury Drug Store','2019-03-05','0000-00-00','0000-00-00','0000-00-00','2019-03-14','0000-00-00','0000-00-00','0000-00-00','1','0','0','1','Contraceptives','ADD / ADHD, Asthma, Heart Attacck, Stroke','Eye Surgery   March 2016',1001,'2019-03-20'),(1003,'','','Mercury Drug Store','2019-03-11','0000-00-00','0000-00-00','0000-00-00','2019-01-27','2017-06-20','0000-00-00','2018-11-20','1','0','0','0','Contracetives','','',1009,'2019-03-20'),(1004,'','','Generics','0000-00-00','0000-00-00','0000-00-00','0000-00-00','','','','','','','','','','','',1010,'2019-03-20'),(1005,'','','','','','','','','','','','','','','','','','',1014,'2019-03-26'),(1006,'','','','','','','','','','','','','','','','','','',1015,'2019-03-26'),(1007,'','','','2019-01-15','0000-00-00','0000-00-00','0000-00-00','2019-03-11','0000-00-00','0000-00-00','0000-00-00','0','0','0','0','','Fractures, High Blood Pressure','eye surgery   March, 2016',1008,'2019-03-28');
/*!40000 ALTER TABLE `tblmedinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmedmaintenance`
--

DROP TABLE IF EXISTS `tblmedmaintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmedmaintenance` (
  `medmaintenanceid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  PRIMARY KEY (`medmaintenanceid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblmedmaintenance_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmedmaintenance`
--

LOCK TABLES `tblmedmaintenance` WRITE;
/*!40000 ALTER TABLE `tblmedmaintenance` DISABLE KEYS */;
INSERT INTO `tblmedmaintenance` VALUES (1001,1008),(1002,1014);
/*!40000 ALTER TABLE `tblmedmaintenance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmedstockcrit`
--

DROP TABLE IF EXISTS `tblmedstockcrit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmedstockcrit` (
  `medcritid` int(11) NOT NULL,
  `medstockinid` int(11) DEFAULT NULL,
  `restockpoint` int(11) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`medcritid`),
  KEY `medstockinid` (`medstockinid`),
  CONSTRAINT `tblmedstockcrit_ibfk_1` FOREIGN KEY (`medstockinid`) REFERENCES `tblmedstockin` (`medstockinid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmedstockcrit`
--

LOCK TABLES `tblmedstockcrit` WRITE;
/*!40000 ALTER TABLE `tblmedstockcrit` DISABLE KEYS */;
INSERT INTO `tblmedstockcrit` VALUES (1001,1001,20,'Normal'),(1002,1002,20,'Normal'),(1003,1003,20,'Normal'),(1004,1004,20,'Normal'),(1005,1005,20,'Critical'),(1007,1007,20,'Out of Stock'),(1008,1008,20,'Out of Stock'),(1009,1009,20,'Out of Stock'),(1010,1010,20,'Out of Stock'),(1011,1011,20,'Out of Stock'),(1012,1012,50,'Normal'),(1013,1013,20,'Out of Stock'),(1014,1014,20,'Out of Stock'),(1015,1015,20,'Out of Stock'),(1016,1016,20,'Out of Stock'),(1017,1017,20,'Out of Stock'),(1018,1018,20,'Normal'),(1019,1019,20,'Normal');
/*!40000 ALTER TABLE `tblmedstockcrit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmedstockin`
--

DROP TABLE IF EXISTS `tblmedstockin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmedstockin` (
  `medstockinid` int(11) NOT NULL,
  `medid` int(11) DEFAULT NULL,
  `stockinquantity` int(11) DEFAULT NULL,
  `stockin_unit` int(11) DEFAULT NULL,
  `unit` varchar(45) DEFAULT NULL,
  `total_qty_pcs` int(11) DEFAULT NULL,
  `pc_per_unit` int(11) DEFAULT NULL,
  PRIMARY KEY (`medstockinid`),
  KEY `medid` (`medid`),
  CONSTRAINT `tblmedstockin_ibfk_1` FOREIGN KEY (`medid`) REFERENCES `tblmedicine` (`medid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmedstockin`
--

LOCK TABLES `tblmedstockin` WRITE;
/*!40000 ALTER TABLE `tblmedstockin` DISABLE KEYS */;
INSERT INTO `tblmedstockin` VALUES (1001,1001,240,20,'Mat (Blister Pack)',240,12),(1002,1002,252,21,'Mat (Blister Pack)',240,12),(1003,1003,240,20,'Mat (Blister Pack)',240,12),(1004,1004,240,20,'Mat (Blister Pack)',240,12),(1005,1005,16,1,'Mat (Blister Pack)',36,12),(1007,1007,0,0,'Mat (Blister Pack)',0,0),(1008,1008,0,0,'Mat (Blister Pack)',0,0),(1009,1009,0,0,'Mat (Blister Pack)',0,0),(1010,1010,0,0,'Mat (Blister Pack)',0,0),(1011,1011,0,0,'Mat (Blister Pack)',0,0),(1012,1012,312,26,'Mat (Blister Pack)',180,12),(1013,1013,0,0,'Mat (Blister Pack)',0,0),(1014,1014,0,0,'Mat (Blister Pack)',0,0),(1015,1015,0,0,'Mat (Blister Pack)',0,0),(1016,1016,0,0,'Mat (Blister Pack)',0,0),(1017,1017,0,0,'Mat (Blister Pack)',0,0),(1018,1018,240,20,'Mat (Blister Pack)',240,12),(1019,1019,168,14,'Mat (Blister Pack)',180,12);
/*!40000 ALTER TABLE `tblmedstockin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmedstockinhist`
--

DROP TABLE IF EXISTS `tblmedstockinhist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblmedstockinhist` (
  `medstockinhist` int(11) NOT NULL,
  `medid` int(11) DEFAULT NULL,
  `stockin_unit` int(11) DEFAULT NULL,
  `unit` varchar(45) DEFAULT NULL,
  `pc_per_unit` int(11) DEFAULT NULL,
  `total_qty_pcs` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`medstockinhist`),
  KEY `medid` (`medid`),
  CONSTRAINT `tblmedstockinhist_ibfk_1` FOREIGN KEY (`medid`) REFERENCES `tblmedicine` (`medid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmedstockinhist`
--

LOCK TABLES `tblmedstockinhist` WRITE;
/*!40000 ALTER TABLE `tblmedstockinhist` DISABLE KEYS */;
INSERT INTO `tblmedstockinhist` VALUES (1001,1002,1,'Mat (Blister Pack)',12,12,'2019-03-22'),(1002,1004,3,'Mat (Blister Pack)',12,36,'2019-03-25'),(1003,1005,10,'Mat (Blister Pack)',12,120,'2019-03-25'),(1004,1002,20,'Mat (Blister Pack)',12,240,'2019-03-25'),(1005,1003,20,'Mat (Blister Pack)',12,240,'2019-03-25'),(1006,1004,20,'Mat (Blister Pack)',12,240,'2019-03-25'),(1007,1012,15,'Mat (Blister Pack)',12,180,'2019-03-25'),(1008,1001,20,'Mat (Blister Pack)',12,240,'2019-03-25'),(1009,1018,20,'Mat (Blister Pack)',12,240,'2019-03-25'),(1010,1012,15,'Mat (Blister Pack)',12,180,'2019-03-25'),(1011,1019,15,'Mat (Blister Pack)',12,180,'2019-03-26'),(1012,1005,2,'Mat (Blister Pack)',12,24,'2019-03-28'),(1013,1005,3,'Mat (Blister Pack)',12,36,'2019-03-28');
/*!40000 ALTER TABLE `tblmedstockinhist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblnbseval`
--

DROP TABLE IF EXISTS `tblnbseval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblnbseval` (
  `nbsevalid` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `race` varchar(50) DEFAULT NULL,
  `motherlastname` varchar(30) DEFAULT NULL,
  `motherfirstname` varchar(30) DEFAULT NULL,
  `mothermiddlename` varchar(30) DEFAULT NULL,
  `motheraddno` varchar(100) DEFAULT NULL,
  `motheraddst` varchar(100) DEFAULT NULL,
  `motheraddbrgy` varchar(100) DEFAULT NULL,
  `motheraddcity` varchar(100) DEFAULT NULL,
  `motheraddstate` varchar(100) DEFAULT NULL,
  `motheraddzip` varchar(100) DEFAULT NULL,
  `landline` varchar(30) DEFAULT NULL,
  `cellno` varchar(30) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`nbsevalid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblnbseval_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblnbseval`
--

LOCK TABLES `tblnbseval` WRITE;
/*!40000 ALTER TABLE `tblnbseval` DISABLE KEYS */;
INSERT INTO `tblnbseval` VALUES (1001,1001,'Asian','asd','asd','asd','34','qwer','qwer','qwer','qwer','1620','0909','09090','2019-02-15'),(1003,1003,'Asian','Lorenzo','Corazon','Escudero','28','E quigue','Aguho','pateros','Manila','1620','642-8549','095646452484','2019-03-20'),(1004,1011,'Asian','asd',NULL,NULL,'25','magbanua','mabuhay','Pasig','Manila','1329','642-8549','09566452484','2019-03-21');
/*!40000 ALTER TABLE `tblnbseval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpatapproval`
--

DROP TABLE IF EXISTS `tblpatapproval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpatapproval` (
  `lastname` varchar(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `middlename` varchar(30) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `birthday` varchar(30) DEFAULT NULL,
  `age_mos` varchar(45) DEFAULT NULL,
  `age` varchar(30) DEFAULT NULL,
  `addressno` varchar(30) DEFAULT NULL,
  `street` varchar(30) DEFAULT NULL,
  `brgy` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `zip` varchar(30) DEFAULT NULL,
  `landline` varchar(30) DEFAULT NULL,
  `cellno` varchar(30) DEFAULT NULL,
  `marstatus` varchar(30) DEFAULT NULL,
  `empname` varchar(30) DEFAULT NULL,
  `empstatus` varchar(30) DEFAULT NULL,
  `emername` varchar(30) DEFAULT NULL,
  `emerno` varchar(30) DEFAULT NULL,
  `emerrel` varchar(30) DEFAULT NULL,
  `emeraddno` varchar(30) DEFAULT NULL,
  `emeraddst` varchar(30) DEFAULT NULL,
  `emeraddbrgy` varchar(30) DEFAULT NULL,
  `emeraddcity` varchar(30) DEFAULT NULL,
  `emeraddstate` varchar(30) DEFAULT NULL,
  `emeraddzip` varchar(30) DEFAULT NULL,
  `patientid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpatapproval`
--

LOCK TABLES `tblpatapproval` WRITE;
/*!40000 ALTER TABLE `tblpatapproval` DISABLE KEYS */;
INSERT INTO `tblpatapproval` VALUES (NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1000);
/*!40000 ALTER TABLE `tblpatapproval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpatient`
--

DROP TABLE IF EXISTS `tblpatient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpatient` (
  `patientid` int(11) NOT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `middlename` varchar(30) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `birthday` varchar(30) DEFAULT NULL,
  `age_mos` varchar(30) DEFAULT NULL,
  `age` varchar(30) DEFAULT NULL,
  `addressno` varchar(100) DEFAULT NULL,
  `street` varchar(100) DEFAULT NULL,
  `brgy` varchar(100) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(30) DEFAULT NULL,
  `landline` varchar(30) DEFAULT NULL,
  `cellno` varchar(30) DEFAULT NULL,
  `marstatus` varchar(30) DEFAULT NULL,
  `empname` varchar(100) DEFAULT NULL,
  `empstatus` varchar(30) DEFAULT NULL,
  `emername` varchar(100) DEFAULT NULL,
  `emerno` varchar(30) DEFAULT NULL,
  `emerrel` varchar(30) DEFAULT NULL,
  `emeraddno` varchar(100) DEFAULT NULL,
  `emeraddst` varchar(30) DEFAULT NULL,
  `emeraddbrgy` varchar(100) DEFAULT NULL,
  `emeraddcity` varchar(100) DEFAULT NULL,
  `emeraddstate` varchar(100) DEFAULT NULL,
  `emeraddzip` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpatient`
--

LOCK TABLES `tblpatient` WRITE;
/*!40000 ALTER TABLE `tblpatient` DISABLE KEYS */;
INSERT INTO `tblpatient` VALUES (1001,'Cabardo','Antoinette','Regala','Female','1997-11-16','21 yrs 4 mos 17 days','21','155','asdf','asd','Taguig','asdf','0660','09909','','Married','','','Cabardo, Itop','099909909','Sibling','155','asdf','asd','Taguig','sdd','0660'),(1002,'Cabardo','Michael','Regala','Male','2017-08-22','1 yrs 7 mos 6 days','1','54','asd','asd','Taguig','asd','1220','09909','0999922999','Single','STI','Part Time','vanz Lorenzo','090909','Classmate','28','E. Quiogue St.','asd','Pateros','qwer','1620'),(1003,'Lorenzo','Vincent','Escudero','Male','2018-10-03','0 yrs 5 mos 25 days','0','28','E. Quiogue St.','Aguho','Pateros','','1620','642-8549','099990999','Single','Factset','Full Time','Lorenzo, Vanz Czeray','090999999','Brother','28','E. Quiogues St.','Aguho','Pateros','Manila','1620'),(1004,'Cabardo','Christopher','Regala','Male','2018-01-19','1 yrs 2 mos 9 days','1','45','asd','ASD','ASDF','FDASF','1620','6456453','090990','Married','Abroad','Full Time','Cabardo, Angelo Nico','19190909','Son','45','asd','ASD','asdas','asd','620'),(1005,'Lorenzo','vino','Escudero','Male','2019-03-13','0 yrs 0 mos 15 days','0','asadf','adf','asdfa','asdf','asdfads','asdf','56746','4567','Single','sdfg','Part Time','sdfg','56846','asd','asd','asd','asdfa','asd','asd','asd'),(1007,'Dela cruz','Jhun','Amores','Male','2010-07-29','8 yrs 7 mos 28 days','8','23','asd','asd','asd','asd','1620','6555566','099909999','Married','sti','Full Time','pedro penduco','099999999','sibling','26','asdasd','asd','asd','asd','0622'),(1008,'dela Vega','Shirley','Lorenzo','Female','1963-01-01','56 yrs 2 mos 27 days','56','58','Equiogue','aguho','pateros','','1620','6428549','099999','Single','','Retired','dela Vega Aida Lorenzo','099999999','Sibling','58','EQuiogue','aguho','Pateros','qweee','1620'),(1009,'De Guzman','Carmen','Galope','Female','1999-03-01','20 yrs 1 mos 0 days','20','asd','ASD','asd','aasd','asdf','1620','6245849','0994184866','Married','Telus','Full Time','Agoncillo, Mark Galope','09999299','Sibling','asd','ASD','asd','ads','asd','1620'),(1010,'Agoncillo','Mark','Castillo','Male','1999-03-01','20 yrs 1 mos 1 days','20','asd','asd','sd','asd','asd','1620','6245849','09999099','Single','Telus','Full Time','Agoncillo, Martin Castillo','6428549','Sibling','asd','asd','sd','asd','asd','1620'),(1011,'Martinez','Kris','Escalanate','Male','2010-02-16','9 yrs 1 mos 11 days','9','25','magbanua','mabuhay','Pasig','Manila','1329','645-4552','09929995456','Single','','Student','Martinez, Francis Retos','099929116','Father','25','Magbanua','mabuhay','Pasig','Manila','1329'),(1012,'Recto','Angela','Aquino','Female','2018-01-25','1 yrs 2 mos 2 days','1','45','camia','Magbanua','Marikina','Manila','1290','518-8998','09564877521','Single','','','Recto, Gina Aquino','09094561278','Mother','45','Camia','Magbanua','Marikina','Manila','1290'),(1013,'Sotto','Charles','Capili','Male','2019-03-12','0 yrs 0 mos 15 days','0','48','Rose','San Mateo','Pasig','Manila','1260','545-7845','0999215466','Single','','','Sotto, Chyna Capili','548-7845','Sister','48','Rose','San Mateo','Pasig','Manila','1260'),(1014,'Dela Cruz','Juan','Caruncho','Male','1958-07-16','60 yrs 8 mos 11 days','60','124','Bridal','San Juan','Makati','Manila','1450','654-8549','09452367845','Widowed','','Retired','Dela Cruz, Pedro Caruncho','09541623488','son','124','Bridal','San Juan','Makati','Manila','1450'),(1015,'Martinez','carla','estrada','Female','1999-03-01','20 yrs 0 mos 26 days','20','25','Epifanio st','san Juan','pasig','Manila','1560','866-0435','09566452484','Single','','Student','645-3456','645-3456','Father','25','Epifanio','san Juan','866-0435','Manila','1560'),(1016,'aasd','asd','sd','Male','2019-01-07','0 yrs 2 mos 21 days','0','12','asd','asd','asd','asd','123','565656','09099','Married','asd','Full Time','123123','123123','asdasd','121','asdasd','asdasd','asdasd','','12312'),(1017,'asd','asd','asd','Male','1995-11-23','23 yrs 4 mos 5 days','23','12','adasd','asd','asdas','sadasd','122','554344','09098856756','Single','asd','Full Time','asd','123123','asdasd','123','efsf','asd','sdfs','sdf','23423'),(1018,'Lorenzo','Vanz Czeray','Escudero','Male','1998-12-16','20 yrs 3 mos 17 days','20','128','E. Quiogue St.','Agustin','Pateros','NCR','1620','642-8549','09956631285','Single','','Student','642-8549','642-8549','Brother','128','E.Quiogue St.','Agustin','Pateros','NCR','1620');
/*!40000 ALTER TABLE `tblpatient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpatlogs`
--

DROP TABLE IF EXISTS `tblpatlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpatlogs` (
  `patientid` int(11) DEFAULT NULL,
  `purpose_of_visit` varchar(100) DEFAULT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblpatlogs_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpatlogs`
--

LOCK TABLES `tblpatlogs` WRITE;
/*!40000 ALTER TABLE `tblpatlogs` DISABLE KEYS */;
INSERT INTO `tblpatlogs` VALUES (1001,'General Adult Checkup','2019-02-21 02:24:55'),(1002,'Child Immunization','2019-03-26 08:26:11'),(1002,'Pediatric Checkup','2019-03-26 08:27:37'),(1009,'Prenatal Checkup','2019-03-26 08:27:08'),(1001,'Prenatal Checkup','2019-03-26 08:30:49'),(1002,'Pediatric Checkup','2019-03-26 08:31:31'),(1009,'Prenatal Checkup','2019-03-26 08:35:28'),(1001,'Prenatal Checkup','2019-03-26 14:00:24'),(1002,'Pediatric Checkup','2019-03-26 14:00:50'),(1003,'New Born Screening','2019-03-27 00:27:09'),(1004,'Child Immunization','2019-03-27 02:47:08'),(1001,'Prenatal Checkup','2019-03-27 09:27:31'),(1001,'Prenatal Checkup','2019-03-27 09:34:56'),(1002,'Child Immunization','2019-03-27 10:29:42'),(1001,'Prenatal Checkup','2019-03-27 11:49:52'),(1002,'Pediatric Checkup','2019-03-27 11:50:02'),(1003,'New Born Screening','2019-03-27 11:50:12'),(1005,'Child Immunization','2019-03-27 11:50:21'),(1010,'Medical Adult Checkup','2019-03-27 11:50:40'),(1003,'New Born Screening','2019-03-27 11:56:44'),(1002,'Pediatric Checkup','2019-03-27 11:56:52'),(1004,'Child Immunization','2019-03-27 12:02:18'),(1001,'Prenatal Checkup','2019-03-27 14:15:49'),(1002,'Pediatric Checkup','2019-03-27 14:16:01'),(1002,'Child Immunization','2019-03-27 14:16:10'),(1003,'New Born Screening','2019-03-27 14:16:19'),(1010,'Medical Adult Checkup','2019-03-27 14:16:32'),(1001,'Prenatal Checkup','2019-03-27 16:47:58'),(1002,'Pediatric Checkup','2019-03-27 16:48:10'),(1002,'Child Immunization','2019-03-27 16:48:19'),(1009,'Medical Adult Checkup','2019-03-27 16:48:29'),(1003,'Child Immunization','2019-03-27 16:48:46'),(1003,'New Born Screening','2019-03-27 16:52:14'),(1001,'Prenatal Checkup','2019-03-28 06:14:35'),(1001,'Prenatal Checkup','2019-03-28 06:15:18'),(1009,'Prenatal Checkup','2019-03-28 10:25:30'),(1001,'Prenatal Checkup','2019-03-28 10:34:21'),(1001,'Prenatal Checkup','2019-03-29 09:58:05'),(1009,'Prenatal Checkup','2019-03-29 10:10:08'),(1001,'Prenatal Checkup','2019-04-01 22:52:10'),(1010,'Medical Adult Checkup','2019-04-01 22:57:18'),(1002,'Child Immunization','2019-04-01 22:57:27'),(1003,'Pediatric Checkup','2019-04-01 22:57:38'),(1010,'Medical Adult Checkup','2019-04-01 23:47:40'),(1010,'Medical Adult Checkup','2019-04-02 14:57:18'),(1010,'Medical Adult Checkup','2019-04-02 15:02:46'),(1010,'Medical Adult Checkup','2019-04-02 16:01:42'),(1010,'Medical Adult Checkup','2019-04-05 06:40:13'),(1010,'Medical Adult Checkup','2019-04-05 06:52:22'),(1010,'Medical Adult Checkup','2019-04-05 08:24:50');
/*!40000 ALTER TABLE `tblpatlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblperinfo`
--

DROP TABLE IF EXISTS `tblperinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblperinfo` (
  `perinfoid` int(11) NOT NULL,
  `occupation` varchar(50) DEFAULT NULL,
  `spouse` varchar(100) DEFAULT NULL,
  `race` varchar(50) DEFAULT NULL,
  `childno` varchar(20) DEFAULT NULL,
  `children` varchar(500) DEFAULT NULL,
  `physician` varchar(500) DEFAULT NULL,
  `patientid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`perinfoid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblperinfo_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblperinfo`
--

LOCK TABLES `tblperinfo` WRITE;
/*!40000 ALTER TABLE `tblperinfo` DISABLE KEYS */;
INSERT INTO `tblperinfo` VALUES (1001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-03-20'),(1002,'housewife','Cabardo, Angelo ','Asian','1','Cabardo, Nicole   1','Dr. Lee   Opthalmologist   Pasig',1001,'2019-03-20'),(1003,'housewife','De Duzman, Ian Lopez','Asian','','','Dra. Lopez   Ob gyne   Pasay',1009,'2019-03-20'),(1004,'','','Asian','1','Agoncillo, Martin   5','',1010,'2019-03-20'),(1005,'asd','','Asian','','','',1014,'2019-03-26'),(1006,'','','Asian','','','',1015,'2019-03-26'),(1007,'teacher','','Asian','','','',1008,'2019-03-28');
/*!40000 ALTER TABLE `tblperinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblpnhealthplan`
--

DROP TABLE IF EXISTS `tblpnhealthplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblpnhealthplan` (
  `pnhealthplanid` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `months` varchar(30) DEFAULT NULL,
  `visits` varchar(30) DEFAULT NULL,
  `illnesses` varchar(300) DEFAULT NULL,
  `q1` varchar(30) DEFAULT NULL,
  `q2` varchar(30) DEFAULT NULL,
  `q3` varchar(30) DEFAULT NULL,
  `q4` varchar(30) DEFAULT NULL,
  `hprovider1` varchar(100) DEFAULT NULL,
  `date1` date DEFAULT NULL,
  `hprovider2` varchar(100) DEFAULT NULL,
  `date2` date DEFAULT NULL,
  `hprovider3` varchar(100) DEFAULT NULL,
  `date3` date DEFAULT NULL,
  `hprovider4` varchar(100) DEFAULT NULL,
  `date4` date DEFAULT NULL,
  `hprovider5` varchar(100) DEFAULT NULL,
  `date5` date DEFAULT NULL,
  `reason` varchar(300) DEFAULT NULL,
  `transport` varchar(100) DEFAULT NULL,
  `hprovider` varchar(100) DEFAULT NULL,
  `patientid` int(11) DEFAULT NULL,
  PRIMARY KEY (`pnhealthplanid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblpnhealthplan_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblpnhealthplan`
--

LOCK TABLES `tblpnhealthplan` WRITE;
/*!40000 ALTER TABLE `tblpnhealthplan` DISABLE KEYS */;
INSERT INTO `tblpnhealthplan` VALUES (1001,'2019-02-06','1','1','viginal bleeding','Yes','Yes','No','Yes','MP','2019-02-04','MP','2019-02-04','MP','2019-02-04','MP','2019-02-04','MP','2019-02-04','asd','Grab','MP',1001),(1002,'2019-03-20','2','1','','Yes','Yes','Yes','Yes','Mahabang Parang Health Center','2019-06-20','Mahabang Parang Health Center','2019-07-18','Mahabang Parang Health Center','2019-03-20','Mahabang Parang Health Center','2019-11-26','Mahabang Parang Health Center','2019-03-21','Premature Dalivery','Grab','Angono State Hospital',1009);
/*!40000 ALTER TABLE `tblpnhealthplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprescpopulate`
--

DROP TABLE IF EXISTS `tblprescpopulate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblprescpopulate` (
  `medication` varchar(100) DEFAULT NULL,
  `strength` varchar(45) DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL,
  `route` varchar(45) DEFAULT NULL,
  `frequency` varchar(45) DEFAULT NULL,
  `duration` varchar(45) DEFAULT NULL,
  `Reason` varchar(100) DEFAULT NULL,
  `Quantity` varchar(45) DEFAULT NULL,
  `refills` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprescpopulate`
--

LOCK TABLES `tblprescpopulate` WRITE;
/*!40000 ALTER TABLE `tblprescpopulate` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblprescpopulate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblprescriptionhist`
--

DROP TABLE IF EXISTS `tblprescriptionhist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblprescriptionhist` (
  `medication` varchar(45) DEFAULT NULL,
  `strength` varchar(45) DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL,
  `route` varchar(45) DEFAULT NULL,
  `frequency` varchar(45) DEFAULT NULL,
  `duration` varchar(45) DEFAULT NULL,
  `reason` varchar(45) DEFAULT NULL,
  `quantity` varchar(45) DEFAULT NULL,
  `refills` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `patientid` int(11) DEFAULT NULL,
  `program` varchar(45) DEFAULT NULL,
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblprescriptionhist_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblprescriptionhist`
--

LOCK TABLES `tblprescriptionhist` WRITE;
/*!40000 ALTER TABLE `tblprescriptionhist` DISABLE KEYS */;
INSERT INTO `tblprescriptionhist` VALUES ('Biogesic','asd','asd','asd','asd',NULL,'asd','5','0','2019-03-25',1001,'Medical Adult Checkup'),('Biogesic','asd','asd','By Mouth (PO)','Daily',NULL,'asd','12','0','2019-03-25',1001,'Medical Adult Checkup'),('Bioflu','?','2 tablets','By Mouth (PO)','Bed Time (QHS)',NULL,'fever','6','0','2019-03-26',1001,'Prenatal Checkup'),('neozep','50 mg','1 cap','By Mouth (PO)','Daily',NULL,'asd','10','0','2019-03-26',1001,'Medical Adult Checkup'),('Antibiotic','?','2 caps','By Mouth (PO)','Daily',NULL,'asd','12','0','2019-03-26',1014,'Medical Adult Checkup'),('Amlodipine','asdsad','asd','By Mouth (PO)','Every Other Day',NULL,'asd','12','0','2019-03-26',1002,'Pediatric Checkup'),('Paracetamol','50 mg','1 cap','By Mouth (PO)','Daily',NULL,'headache','2','0','2019-03-28',1009,'Prenatal Checkup'),('Acetaminophen','50 mg','2 caps','By Mouth (PO)','Daily','0 weeks, 2 days','Headache','4','0','2019-04-02',1010,'Medical Adult Checkup'),('Biogesic','200 mg','1 caps','By Mouth (PO)','Daily','0 weeks, 2 days','flu','2','0','2019-04-02',1010,'Medical Adult Checkup'),('Ibuprofen','50 mg','1 cap','By Mouth (PO)','Daily','0 weeks, 2 days','Headache','2','0','2019-04-02',1010,'Medical Adult Checkup'),('loperamide','20 mg','1 cap','By Mouth (PO)','Daily','0 weeks, 1 days','lbm','1','0','2019-04-05',1010,'Medical Adult Checkup'),('loperamide','20 mg','1 cap','By Mouth (PO)','Daily','0 weeks, 1 days','lbm','1','0','2019-04-05',1010,'Medical Adult Checkup'),('loperamide','20 mg','1 cap','By Mouth (PO)','Daily','0 weeks, 1 days','lbm','1','0','2019-04-05',1010,'Medical Adult Checkup'),('Paracetamol','50 mg','1 cap','By Mouth (PO)','Daily','0 weeks, 1 days','headache','1','0','2019-04-05',1010,'Medical Adult Checkup');
/*!40000 ALTER TABLE `tblprescriptionhist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblqueue`
--

DROP TABLE IF EXISTS `tblqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblqueue` (
  `queueno` int(11) NOT NULL,
  `patientid` int(11) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `concern` varchar(100) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `priority` varchar(30) DEFAULT NULL,
  `priority_status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`queueno`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblqueue_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblqueue`
--

LOCK TABLES `tblqueue` WRITE;
/*!40000 ALTER TABLE `tblqueue` DISABLE KEYS */;
INSERT INTO `tblqueue` VALUES (1,1010,'Served','Medical Adult Checkup','2019-04-05','No',''),(2,1010,'Served','Medical Adult Checkup','2019-04-05','No','');
/*!40000 ALTER TABLE `tblqueue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblroom`
--

DROP TABLE IF EXISTS `tblroom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblroom` (
  `userid` int(11) DEFAULT NULL,
  `roomno` varchar(30) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `roomid` varchar(45) NOT NULL,
  PRIMARY KEY (`roomid`),
  KEY `userid` (`userid`),
  CONSTRAINT `tblroom_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblroom`
--

LOCK TABLES `tblroom` WRITE;
/*!40000 ALTER TABLE `tblroom` DISABLE KEYS */;
INSERT INTO `tblroom` VALUES (1003,'','OUT','1');
/*!40000 ALTER TABLE `tblroom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblschedule`
--

DROP TABLE IF EXISTS `tblschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblschedule` (
  `scheduleid` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `scheduleday` varchar(100) DEFAULT NULL,
  `schedulestart` time DEFAULT NULL,
  `scheduleend` time DEFAULT NULL,
  `serviceid` int(11) DEFAULT NULL,
  PRIMARY KEY (`scheduleid`),
  KEY `userid` (`userid`),
  KEY `serviceid` (`serviceid`),
  CONSTRAINT `tblschedule_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `tblusers` (`userid`),
  CONSTRAINT `tblschedule_ibfk_2` FOREIGN KEY (`serviceid`) REFERENCES `tblservice` (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblschedule`
--

LOCK TABLES `tblschedule` WRITE;
/*!40000 ALTER TABLE `tblschedule` DISABLE KEYS */;
INSERT INTO `tblschedule` VALUES (1013,1003,'Wednesday','09:00:00','12:00:00',1005),(1014,1002,'Monday, Wednesday, Friday','08:00:00','05:00:00',1006),(1015,1003,'Monday, Friday','09:00:00','12:00:00',1001),(1016,1003,'Wednesday','08:00:00','12:00:00',1002),(1017,1003,'Tuesday, Thursday','08:00:00','05:00:00',1003),(1018,1003,'Wednesday','08:00:00','12:00:00',1004);
/*!40000 ALTER TABLE `tblschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblservfee`
--

DROP TABLE IF EXISTS `tblservfee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblservfee` (
  `servfeeid` int(11) NOT NULL,
  `servicename` varchar(100) DEFAULT NULL,
  `servicefee` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`servfeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblservfee`
--

LOCK TABLES `tblservfee` WRITE;
/*!40000 ALTER TABLE `tblservfee` DISABLE KEYS */;
INSERT INTO `tblservfee` VALUES (1001,'Prenatal Package','750.00'),(1002,'Sample','1000');
/*!40000 ALTER TABLE `tblservfee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblservice`
--

DROP TABLE IF EXISTS `tblservice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblservice` (
  `serviceid` int(11) NOT NULL,
  `servicetype` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`serviceid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblservice`
--

LOCK TABLES `tblservice` WRITE;
/*!40000 ALTER TABLE `tblservice` DISABLE KEYS */;
INSERT INTO `tblservice` VALUES (1001,'Medical Adult Checkup'),(1002,'New Born Screening'),(1003,'Prenatal Checkup'),(1004,'Child Immunization'),(1005,'Pediatric Checkup'),(1006,'Medicine Dispensing');
/*!40000 ALTER TABLE `tblservice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblsocialinfo`
--

DROP TABLE IF EXISTS `tblsocialinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblsocialinfo` (
  `socinfoid` int(11) NOT NULL,
  `q1` varchar(50) DEFAULT NULL,
  `q2` varchar(50) DEFAULT NULL,
  `q3` varchar(50) DEFAULT NULL,
  `q4` varchar(50) DEFAULT NULL,
  `q5` varchar(50) DEFAULT NULL,
  `q6` varchar(50) DEFAULT NULL,
  `q7` varchar(50) DEFAULT NULL,
  `q8` varchar(50) DEFAULT NULL,
  `q9` varchar(300) DEFAULT NULL,
  `q10` varchar(50) DEFAULT NULL,
  `q11` varchar(300) DEFAULT NULL,
  `q12` varchar(50) DEFAULT NULL,
  `q13` varchar(300) DEFAULT NULL,
  `q14` varchar(50) DEFAULT NULL,
  `q15` varchar(300) DEFAULT NULL,
  `q16` varchar(50) DEFAULT NULL,
  `q17` varchar(300) DEFAULT NULL,
  `q18` varchar(50) DEFAULT NULL,
  `q19` varchar(50) DEFAULT NULL,
  `patientid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`socinfoid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblsocialinfo_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblsocialinfo`
--

LOCK TABLES `tblsocialinfo` WRITE;
/*!40000 ALTER TABLE `tblsocialinfo` DISABLE KEYS */;
INSERT INTO `tblsocialinfo` VALUES (1001,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-03-20'),(1002,'Yes','1','2','No','Yes','Yes','2 mos','Yes','beer   1x a week','No','','Yes','Cardio Exercises   2x a week','','low Sugar, low calorie','Yes','','No','No',1001,'2019-03-20'),(1004,'No','','','','','','','','','','','','','','','','','','',1010,'2019-03-20'),(1005,'','','','','','','','','','','','','','','','','','','',1014,'2019-03-26'),(1006,'','','','','','','','','','','','','','','','','','','',1015,'2019-03-26'),(1007,'No','','','','','','','No','','No','','Yes','cardio   1x a week, yoga   1x a month','','','No','','No','No',1008,'2019-03-28');
/*!40000 ALTER TABLE `tblsocialinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblusers`
--

DROP TABLE IF EXISTS `tblusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblusers` (
  `userid` int(11) NOT NULL,
  `usertype` varchar(30) DEFAULT NULL,
  `lastname` varchar(30) DEFAULT NULL,
  `firstname` varchar(30) DEFAULT NULL,
  `middlename` varchar(30) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `repass` varchar(30) DEFAULT NULL,
  `securityquestion` varchar(50) DEFAULT NULL,
  `answer` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblusers`
--

LOCK TABLES `tblusers` WRITE;
/*!40000 ALTER TABLE `tblusers` DISABLE KEYS */;
INSERT INTO `tblusers` VALUES (1001,'Admin','Lorenzo','Vanz Czeray','Escudero','Admin','1234','1234','What is your favorite  food?','chicken'),(1002,'Assistant','Ruiz','Elizabeth','Candelaria','Nurse','1234','1234','What is your favorite  food?','chicken'),(1003,'Doctor','Miranda','Gingergrace','Andalio','Doctor','1234','1234','What is your favorite  food?','chicken'),(1004,'Doctor','Lozo','Jose','Andres','doc2','1234','1234','What is your favorite  food?','chicken');
/*!40000 ALTER TABLE `tblusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblvitsign`
--

DROP TABLE IF EXISTS `tblvitsign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblvitsign` (
  `vitsignid` int(11) NOT NULL,
  `bp` varchar(30) DEFAULT NULL,
  `bpstat` varchar(100) DEFAULT NULL,
  `hr` varchar(30) DEFAULT NULL,
  `hrstat` varchar(100) DEFAULT NULL,
  `rr` varchar(30) DEFAULT NULL,
  `rrstat` varchar(100) DEFAULT NULL,
  `temp` varchar(30) DEFAULT NULL,
  `tempstat` varchar(100) DEFAULT NULL,
  `weight` varchar(50) DEFAULT NULL,
  `height` varchar(30) DEFAULT NULL,
  `bmi` varchar(30) DEFAULT NULL,
  `bmistatus` varchar(30) DEFAULT NULL,
  `patientid` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`vitsignid`),
  KEY `patientid` (`patientid`),
  CONSTRAINT `tblvitsign_ibfk_1` FOREIGN KEY (`patientid`) REFERENCES `tblpatient` (`patientid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblvitsign`
--

LOCK TABLES `tblvitsign` WRITE;
/*!40000 ALTER TABLE `tblvitsign` DISABLE KEYS */;
INSERT INTO `tblvitsign` VALUES (1013,'120/80','Normal','63','Normal Heart Rate','16','Normal Respiratory Rate','37.45','Normal Temperature','59','1.78','18.62','Underweight',1001,'2019-03-20'),(1014,'120/80','','61','Normal Heart Rate','20','Normal Respiratory Rate','37.56','Normal Temperature','15.34','1.02','14.74','Underweight',1002,'2019-03-20'),(1015,'120/80','','65','Normal Heart Rate','18','Normal Respiratory Rate','37.39','Normal Temperature','15.12','1.23','9.99','Underweight',1004,'2019-03-20'),(1016,'120/80','','64','Normal Heart Rate','16','Normal Respiratory Rate','37.12','Normal Temperature','3.31','0.04','2068.75','Obese',1003,'2019-03-20'),(1017,'120/80','','60','Normal Heart Rate','16','Normal Respiratory Rate','37.45','Normal Temperature','64.12','1.78','20.24','Normal',1009,'2019-03-20'),(1018,'120/80','','60','Normal Heart Rate','22','Above Normal Respiratory Rate (Tachypneic)','36.15','Below Normal Temperature (Hypothermic)','49.12','1.56','20.18','Normal',1008,'2019-03-20'),(1019,'120/80','Normal','65','Normal Heart Rate','15','Normal Respiratory Rate','37.45','Normal Temperature','64','1.74','21.14','Normal',1010,'2019-03-20'),(1020,'/','','65','Normal Heart Rate','15','Normal Respiratory Rate','37.67','Above Normal Temperature (Hyperthermic)','12.78','1.02','12.28','Underweight',1011,'2019-03-20'),(1021,'120/80','Normal','60','Normal Heart Rate','16','Normal Respiratory Rate','37.41','Normal Temperature','62.13','1.78','19.61','Normal',1001,'2019-03-25'),(1022,'120/80','Normal','60','Normal Heart Rate','15','Normal Respiratory Rate','36.45','Normal Temperature','64.12','1.78','20.24','Normal',1009,'2019-03-25'),(1023,'120/80','Normal','60','Normal Heart Rate','15','Normal Respiratory Rate','37.45','Normal Temperature','64.78','1.79','20.22','Normal',1001,'2019-03-26'),(1024,'/','','60','Normal Heart Rate','15','Normal Respiratory Rate','37.45','Normal Temperature','12.34','0.89','15.58','Underweight',1002,'2019-03-26'),(1025,'120/80','Normal','60','Normal Heart Rate','14','Normal Respiratory Rate','37','Normal Temperature','55.34','1.89','15.49','Underweight',1009,'2019-03-26'),(1026,'/','','60','Normal Heart Rate','14','Normal Respiratory Rate','37','Normal Temperature','3.12','0.86','4.22','Underweight',1004,'2019-03-26'),(1027,'120/80','Normal','60','Normal Heart Rate','16','Normal Respiratory Rate','37.45','Normal Temperature','59.13','1.89','16.55','Underweight',1014,'2019-03-26'),(1028,'/','','','','','','','','','','','',1015,'2019-03-26'),(1029,'/','','60','Normal Heart Rate','15','Normal Respiratory Rate','37','Normal Temperature','3.23','1.89','0.90','Underweight',1002,'2019-03-26'),(1030,'/','','60','Normal Heart Rate','15','Normal Respiratory Rate','37','Normal Temperature','3.25','0.85','4.50','Underweight',1004,'2019-03-26'),(1031,'120/80','Normal','60','Normal Heart Rate','15','Normal Respiratory Rate','37','Normal Temperature','59.45','1.78','18.76','Underweight',1009,'2019-03-26'),(1032,'120/80','Normal','60','Normal Heart Rate','12','Normal Respiratory Rate','37','Normal Temperature','56.12','1.54','23.66','Normal',1010,'2019-03-26'),(1033,'/','','60','Normal Heart Rate','12','Normal Respiratory Rate','37','Normal Temperature','2.53','.33','23.23','Normal',1011,'2019-03-26'),(1034,'120/80','Normal','62','Normal Heart Rate','15','Normal Respiratory Rate','37.45','Normal Temperature','58.12','1.78','18.34','Underweight',1014,'2019-03-26'),(1035,'/','','60','Normal Heart Rate','12','Normal Respiratory Rate','37','Normal Temperature','3.26','0.39','21.43','Normal',1003,'2019-03-27'),(1036,'/','','60','Normal Heart Rate','15','Normal Respiratory Rate','37','Normal Temperature','3.3','.40','20.63','Normal',1004,'2019-03-27'),(1037,'120/80','Normal','60','Normal Heart Rate','15','Normal Respiratory Rate','37','Normal Temperature','59','1.78','18.62','Underweight',1001,'2019-03-27'),(1038,'120/80','Normal','60','Normal Heart Rate','15','Normal Respiratory Rate','37.15','Normal Temperature','59','1.78','18.62','Underweight',1001,'2019-03-28'),(1039,'/','','60','Normal Heart Rate','15','Normal Respiratory Rate','37.14','Normal Temperature','15.34','1.56','6.30','Underweight',1002,'2019-03-28'),(1040,'/','','60','Normal Heart Rate','15','Normal Respiratory Rate','37.45','Normal Temperature','3.12','0.05','1248.00','Obese',1003,'2019-03-28'),(1041,'/','','60','Normal Heart Rate','16','Normal Respiratory Rate','37.45','Normal Temperature','3.3','0.40','20.63','Normal',1004,'2019-03-28'),(1042,'/','','60','Normal Heart Rate','16','Normal Respiratory Rate','37.45','Normal Temperature','12.45','.45','61.48','Obese',1005,'2019-03-28'),(1043,'/','','60','Normal Heart Rate','15','Normal Respiratory Rate','37.12','Normal Temperature','3.33','0.21','75.51','Obese',1007,'2019-03-28'),(1044,'120/80','Normal','60','Normal Heart Rate','16','Normal Respiratory Rate','37.45','Normal Temperature','45.12','.56','143.88','Obese',1008,'2019-03-28'),(1045,'120/','80','60','Normal Heart Rate','15','Normal Respiratory Rate','37.43','Normal Temperature','59.45','1.78','18.76','Underweight',1009,'2019-03-28'),(1046,'120/80','Normal','60','Normal Heart Rate','15','Normal Respiratory Rate','37','Normal Temperature','59','1.78','18.62','Underweight',1001,'2019-03-29');
/*!40000 ALTER TABLE `tblvitsign` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-08  9:11:51
